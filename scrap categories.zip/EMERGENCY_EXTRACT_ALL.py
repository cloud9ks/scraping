#!/usr/bin/env python3
"""
VERSIONE EMERGENCY - SALVA TUTTI I LINK
Usa questo se le altre versioni danno ancora 0 categorie
"""

import time
import json
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

def extract_all_links():
    print("\n" + "="*60)
    print(" ESTRAZIONE EMERGENCY - TUTTI I LINK")
    print("="*60)
    
    with open('config.json', 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    options = Options()
    driver = webdriver.Chrome(options=options)
    driver.maximize_window()
    
    categories = []
    
    try:
        # LOGIN
        print("\n🔐 LOGIN...")
        driver.get(config['site']['login_url'])
        time.sleep(3)
        
        email_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.login-container form input:nth-child(1)"))
        )
        email_field.send_keys(config['credentials']['email'])
        
        password_field = driver.find_element(By.CSS_SELECTOR, "div.login-container form input.form-wide.mt-3")
        password_field.send_keys(config['credentials']['password'])
        
        submit_button = driver.find_element(By.CSS_SELECTOR, "div.login-container form button")
        submit_button.click()
        time.sleep(5)
        print("✅ Login OK")
        
        # ESTRAI LINK
        print("\n📦 ESTRAZIONE LINK...")
        time.sleep(3)
        
        mobile_nav = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "nav.mobile-nav"))
        )
        
        all_links = driver.find_elements(By.CSS_SELECTOR, "nav.mobile-nav a")
        print(f"✓ Trovati {len(all_links)} link totali")
        
        print("\n🔓 SALVATAGGIO TUTTI I LINK (senza filtri)...")
        
        for link in all_links:
            try:
                href = link.get_attribute('href')
                text = link.text.strip()
                
                # FILTRI MINIMI MINIMI
                if not href or not text or len(text) < 2:
                    continue
                
                # Escludi solo social e account base
                skip = ['facebook.com', 'instagram.com', 'mailto:', 'tel:', '/account', '/cart']
                if any(x in href for x in skip):
                    continue
                
                # SALVA TUTTO IL RESTO (senza duplicati)
                if not any(cat['url'] == href for cat in categories):
                    categories.append({
                        'name': text,
                        'url': href
                    })
            except:
                pass
        
        print(f"\n✅ TOTALE: {len(categories)} categorie salvate")
        
        if categories:
            print(f"\nPrime 30 categorie:")
            for i, cat in enumerate(categories[:30], 1):
                print(f"  {i}. {cat['name']}")
                print(f"     → {cat['url'][:80]}")
        
        # Salva in file
        with open('categorie_estratte.json', 'w', encoding='utf-8') as f:
            json.dump(categories, f, indent=2, ensure_ascii=False)
        print(f"\n💾 Salvate in: categorie_estratte.json")
        
    except Exception as e:
        print(f"\n❌ ERRORE: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        driver.quit()
        print("\n🔒 Browser chiuso")
    
    return len(categories) > 0

if __name__ == "__main__":
    success = extract_all_links()
    input("\nPremi INVIO per uscire...")
    sys.exit(0 if success else 1)
