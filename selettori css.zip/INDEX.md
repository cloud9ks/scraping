# 📦 HidrosPoint B2B Scraper - Indice Completo

## 🎯 Cosa Trovi Qui

Soluzione completa per lo scraping del catalogo B2B di HidrosPoint (https://b2b.hidros.com)

---

## 📄 File Principali

### 🚀 Script di Scraping

| File | Descrizione | Quando Usarlo |
|------|-------------|---------------|
| **hidrospoint_scraper_console.js** | Script per console browser | ✅ Setup veloce, debug facile |
| **hidrospoint_scraper_puppeteer.js** | Script Node.js automatizzato | ✅ Automazione completa |
| **test_hidrospoint.js** | Test rapido di connessione | ✅ Prima di iniziare |

### 📚 Guide e Documentazione

| File | Cosa Contiene |
|------|---------------|
| **README_HIDROSPOINT.md** | Guida rapida per iniziare |
| **GUIDA_SELETTORI.md** | Come modificare i selettori CSS |
| **.env.example** | Template per le credenziali |
| **package_hidrospoint.json** | Dipendenze Node.js |

---

## 🚀 Quick Start

### Opzione A: Console Browser (5 minuti)

```
1. Apri browser → https://b2b.hidros.com
2. Login manualmente
3. F12 → Console
4. Copia/incolla: hidrospoint_scraper_console.js
5. Esegui: await scrapeHidrosPoint()
✅ File JSON scaricato!
```

### Opzione B: Puppeteer (Automatico)

```bash
1. npm install puppeteer
2. Modifica credenziali in hidrospoint_scraper_puppeteer.js
3. node hidrospoint_scraper_puppeteer.js
✅ Scraping completo automatico!
```

---

## 📊 Output Generato

### Formato JSON
```json
{
  "scrapingDate": "2025-11-03T...",
  "categories": [
    {
      "name": "VALVOLE ARRESTO A SFERA",
      "url": "https://..."
    }
  ],
  "products": [
    {
      "code": "B3003/8",
      "name": "VALVOLA ARRESTO A SFERA...",
      "price": "€3,0962",
      "availability": "DISPONIBILE",
      "brand": "BUGATTI",
      "category": "VALVOLE ARRESTO A SFERA",
      "image": "https://...",
      "specs": { "UM": "37", "MV": "1", "CFZ": "24" },
      "url": "https://..."
    }
  ],
  "brands": [
    { "name": "Bugatti", "count": "25" }
  ],
  "totalProducts": 1234
}
```

### Formato CSV
```csv
Codice,Nome,Prezzo,Disponibilità,Marca,Categoria,URL,Immagine
"B3003/8","VALVOLA ARRESTO...","€3,0962","DISPONIBILE","BUGATTI",...
```

---

## 🎬 Workflow Consigliato

### 1. Prima Volta (Setup & Test)

```bash
# Test connessione
node test_hidrospoint.js

# Se OK, procedi con scraping
```

### 2. Scraping Singola Categoria

```javascript
// Console Browser
await scrapeHidrosPoint()
```

### 3. Scraping Completo Catalogo

```bash
# Puppeteer
node hidrospoint_scraper_puppeteer.js
```

### 4. Se Qualcosa Non Funziona

```
1. Leggi GUIDA_SELETTORI.md
2. Modifica i selettori CSS
3. Riprova il test
```

---

## 🔧 Configurazione

### Credenziali (Puppeteer)

**Metodo 1**: Modifica il file
```javascript
// In hidrospoint_scraper_puppeteer.js
credentials: {
    username: 'TUO_USERNAME',
    password: 'TUA_PASSWORD'
}
```

**Metodo 2**: Variabili d'ambiente (più sicuro)
```bash
export HIDROS_USERNAME="username"
export HIDROS_PASSWORD="password"
node hidrospoint_scraper_puppeteer.js
```

### Velocità Scraping

```javascript
// In hidrospoint_scraper_puppeteer.js
waitTime: 2000,  // Pausa tra pagine (ms)
```

⚠️ **Non andare sotto 1000ms** o rischi il ban!

### Modalità Esecuzione

```javascript
headless: false  // Vedi il browser (debug)
headless: true   // Nascosto (produzione)
```

---

## 📈 Performance

| Metodo | Velocità | Facilità | Automazione |
|--------|----------|----------|-------------|
| Console | ⚡⚡⚡ | ✅✅✅ | ⚠️ |
| Puppeteer | ⚡⚡ | ✅✅ | ✅✅✅ |

**Consiglio**: 
- Prototipo/Test → Console
- Produzione → Puppeteer

---

## 🐛 Troubleshooting

### Problema: Login Fallito
```
Soluzione:
1. Verifica username/password
2. Prova login manuale
3. Controlla cookies.json
```

### Problema: Nessun Prodotto Trovato
```
Soluzione:
1. Leggi GUIDA_SELETTORI.md
2. Usa test_hidrospoint.js
3. Modifica selettori in CONFIG
```

### Problema: Timeout
```
Soluzione:
1. Aumenta waitTime → 3000
2. Verifica connessione internet
3. Controlla se il sito è online
```

### Problema: Errori Strani
```
Soluzione:
1. Cancella cookies.json
2. Svuota cache browser
3. Riavvia e riprova
```

---

## 💡 Tips Pro

### Tip #1: Checkpoint Automatici
Lo scraper Puppeteer salva checkpoint ogni 5 categorie.
Se si interrompe, cerca i file `checkpoint_*.json`

### Tip #2: Rate Limiting
Usa `waitTime: 2000` minimo per evitare il ban.
Meglio 3000ms se hai molte categorie.

### Tip #3: Headless Mode
Prima volta: `headless: false` (vedi cosa succede)
Produzione: `headless: true` (più veloce)

### Tip #4: Cookies Salvati
Puppeteer salva i cookies. Login necessario solo la prima volta!

### Tip #5: Debug Console
La console browser è perfetta per testare selettori:
```javascript
document.querySelectorAll('TUO_SELETTORE').length
```

---

## 📞 Help & Support

### Prima di chiedere aiuto:

1. ✅ Hai letto README_HIDROSPOINT.md?
2. ✅ Hai eseguito test_hidrospoint.js?
3. ✅ Hai controllato GUIDA_SELETTORI.md?
4. ✅ Hai provato nella console browser?
5. ✅ Hai guardato lo screenshot di debug?

### File utili per debug:

- `test_screenshot.png` - Screenshot della pagina
- `checkpoint_*.json` - Backup intermedi
- `cookies.json` - Sessione salvata
- Console DevTools (F12) - Errori JavaScript

---

## 📝 Checklist Setup

```
☐ Node.js installato (v16+)
☐ npm install puppeteer
☐ Credenziali inserite
☐ Test eseguito: node test_hidrospoint.js
☐ Test OK → Procedi con scraping
☐ Test FAIL → Leggi GUIDA_SELETTORI.md
```

---

## 🎯 Casi d'Uso

### Scenario 1: "Ho bisogno di 1 categoria velocemente"
→ Usa **Console Browser**
```javascript
await scrapeHidrosPoint()
```

### Scenario 2: "Voglio tutto il catalogo"
→ Usa **Puppeteer**
```bash
node hidrospoint_scraper_puppeteer.js
```

### Scenario 3: "I selettori non funzionano"
→ Leggi **GUIDA_SELETTORI.md**
→ Esegui **test_hidrospoint.js**

### Scenario 4: "Voglio automatizzare ogni giorno"
→ Usa **Puppeteer** + **Cron Job**
```bash
# Crontab esempio (ogni giorno alle 2:00)
0 2 * * * cd /path/to/scraper && node hidrospoint_scraper_puppeteer.js
```

---

## 🔐 Sicurezza

⚠️ **IMPORTANTE**:
- Non condividere `cookies.json`
- Non committare credenziali su Git
- Usa `.env` per le password
- Aggiungi al `.gitignore`:
  ```
  .env
  cookies.json
  hidros_scraping_output/
  ```

---

## 📦 Struttura File Output

```
hidros_scraping_output/
├── hidrospoint_completo_[timestamp].json    # Tutti i dati
├── hidrospoint_prodotti_[timestamp].csv     # Solo prodotti
├── checkpoint_5.json                        # Backup ogni 5 categorie
├── checkpoint_10.json
├── cookies.json                             # Sessione salvata
└── test_screenshot.png                      # Screenshot debug
```

---

## 🚀 Versioni Future (TODO)

- [ ] Scraping immagini prodotto
- [ ] Export Excel (XLSX)
- [ ] Confronto prezzi storico
- [ ] Dashboard web risultati
- [ ] Notifiche email fine scraping
- [ ] Docker container
- [ ] API REST

---

## 📜 License

MIT License - Usa liberamente per i tuoi progetti

---

## 👤 Credits

**Creato per**: NexNow LTD  
**Progetto**: Web Scraping B2B Suppliers  
**Data**: Novembre 2025  
**Versione**: 1.0.0

---

## 🎉 Ready to Start!

```bash
# Quick Start in 3 comandi:
npm install puppeteer
node test_hidrospoint.js
node hidrospoint_scraper_puppeteer.js

# Oppure usa la console browser per ancora più veloce! 🚀
```

**Buon scraping! 📊**
