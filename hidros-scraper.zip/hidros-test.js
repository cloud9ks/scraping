const puppeteer = require('puppeteer');

const LOGIN_EMAIL = 'info@nextradeitalia.com';
const LOGIN_PASSWORD = '05391463';
const BASE_URL = 'https://b2b.hidros.com';

async function testLogin() {
    console.log('🧪 Test di connessione e login...\n');
    
    const browser = await puppeteer.launch({
        headless: false,
        slowMo: 50
    });
    
    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });
    
    try {
        console.log('1️⃣  Navigazione al sito...');
        await page.goto(BASE_URL, { waitUntil: 'networkidle2', timeout: 30000 });
        console.log('   ✅ Sito raggiunto');
        
        await page.screenshot({ path: 'test-01-homepage.png' });
        
        console.log('\n2️⃣  Compilazione form di login...');
        
        // Cerca il campo email
        const emailSelector = 'input[type="email"], input[name="email"]';
        await page.waitForSelector(emailSelector, { timeout: 10000 });
        await page.type(emailSelector, LOGIN_EMAIL, { delay: 50 });
        console.log('   ✅ Email inserita');
        
        // Cerca il campo password
        const passwordSelector = 'input[type="password"]';
        await page.type(passwordSelector, LOGIN_PASSWORD, { delay: 50 });
        console.log('   ✅ Password inserita');
        
        await page.screenshot({ path: 'test-02-form-filled.png' });
        
        console.log('\n3️⃣  Click sul pulsante di login...');
        await Promise.all([
            page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }),
            page.click('button[type="submit"]')
        ]);
        
        await page.waitForTimeout(3000);
        await page.screenshot({ path: 'test-03-after-login.png' });
        
        // Verifica se siamo loggati
        const url = page.url();
        console.log(`   ✅ Login effettuato! URL attuale: ${url}`);
        
        console.log('\n4️⃣  Test navigazione al catalogo...');
        await page.goto(`${BASE_URL}/valvolame-e-raccorderia`, { waitUntil: 'networkidle2' });
        await page.waitForTimeout(2000);
        await page.screenshot({ path: 'test-04-catalog.png' });
        console.log('   ✅ Catalogo raggiunto');
        
        console.log('\n5️⃣  Ricerca elementi prodotto...');
        const productCount = await page.evaluate(() => {
            const products = document.querySelectorAll('[class*="product"], tr[class*="product"], .product-item');
            return products.length;
        });
        
        console.log(`   ✅ Trovati ${productCount} elementi prodotto sulla pagina`);
        
        console.log('\n✅ TEST COMPLETATO CON SUCCESSO!');
        console.log('📸 Screenshot salvati:');
        console.log('   - test-01-homepage.png');
        console.log('   - test-02-form-filled.png');
        console.log('   - test-03-after-login.png');
        console.log('   - test-04-catalog.png');
        
        // Lascia il browser aperto per 5 secondi
        console.log('\n⏳ Chiusura tra 5 secondi...');
        await page.waitForTimeout(5000);
        
    } catch (error) {
        console.error('\n❌ ERRORE DURANTE IL TEST:');
        console.error(error.message);
        await page.screenshot({ path: 'test-error.png' });
        console.log('📸 Screenshot errore salvato: test-error.png');
    } finally {
        await browser.close();
        console.log('\n👋 Browser chiuso');
    }
}

testLogin();
