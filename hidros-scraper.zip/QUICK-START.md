# 🚀 GUIDA RAPIDA - Hidros Scraper

## 📦 Installazione Veloce

### Windows
1. Apri il terminale (CMD o PowerShell)
2. Vai nella cartella del progetto
3. Esegui: `setup.bat`

### Mac/Linux
1. Apri il terminale
2. Vai nella cartella del progetto
3. Esegui: `chmod +x setup.sh && ./setup.sh`

## ⚡ Uso Immediato

### 1. Test Connessione (5 minuti)
```bash
npm test
```
Questo verifica che tutto funzioni correttamente.

### 2. Scraping Veloce (10-15 minuti)
```bash
npm start
```
Estrae i prodotti dalle categorie principali.

### 3. Scraping Completo (30-60 minuti)
```bash
npm run advanced
```
Estrae TUTTI i prodotti da TUTTE le categorie.

## 📁 Dove Trovo i Risultati?

Dopo lo scraping, troverai:
- `hidros-products.json` - Tutti i prodotti in JSON
- `hidros-products.csv` - Tutti i prodotti in CSV (Excel)
- `hidros-stats.json` - Statistiche
- `screenshots/` - Screenshot per debug

## 🔧 Problemi Comuni

### "node non trovato"
**Soluzione:** Installa Node.js da https://nodejs.org/

### "Login fallito"
**Soluzione:** 
1. Verifica le credenziali negli script
2. Controlla screenshot in `screenshots/`
3. Prova ad aumentare i tempi di attesa

### "Nessun prodotto estratto"
**Soluzione:**
1. Esegui prima `npm test`
2. Usa lo scraper avanzato: `npm run advanced`
3. Controlla gli screenshot

### "Menu non si aprono"
**Soluzione:**
1. Usa lo scraper avanzato (gestione migliore dei menu)
2. Aumenta `slowMo` nel codice a 100-200ms
3. Controlla la connessione internet

## ⚙️ Personalizzazione Base

### Cambiare Credenziali
Apri il file `.js` e modifica:
```javascript
const LOGIN_EMAIL = 'tua@email.com';
const LOGIN_PASSWORD = 'tuapassword';
```

### Modalità Invisibile
Cambia in tutti gli script:
```javascript
headless: true  // false = vedi il browser, true = invisibile
```

### Più Veloce/Lento
```javascript
slowMo: 10   // Più veloce (10ms)
slowMo: 200  // Più lento (200ms)
```

## 📊 Output Esempio

### JSON
```json
{
  "code": "B8101",
  "name": "Valvola arresto...",
  "price": "6.54",
  "availability": "DISPONIBILE",
  "brand": "BUGATTI"
}
```

### CSV (apri con Excel)
```
code,name,price,availability,brand
B8101,Valvola arresto...,6.54,DISPONIBILE,BUGATTI
```

## 🎯 Prossimi Passi

1. ✅ Esegui `npm test` per verificare
2. ✅ Esegui `npm run advanced` per lo scraping completo
3. ✅ Apri i file CSV con Excel
4. ✅ Analizza i dati!

## 📞 Supporto

Se hai problemi:
1. Controlla README.md per guida completa
2. Controlla screenshot in `screenshots/`
3. Guarda i log nel terminale

## ⚠️ Note Importanti

- ⏱️ Lo scraping completo può richiedere 30-60 minuti
- 🌐 Serve una connessione internet stabile
- 💻 Il browser si aprirà (a meno che non usi headless: true)
- 📸 Vengono salvati screenshot per debug
- 🔐 Le credenziali sono nel codice - NON condividerle!

---

**Buon scraping! 🎉**

Per domande avanzate, leggi il README.md completo.
