#!/bin/bash
# ============================================================
#  HIDROS SCRAPER CORRETTO - Avvio Rapido Linux/Mac
# ============================================================

show_banner() {
    echo ""
    echo "============================================================"
    echo " HIDROS B2B SCRAPER - VERSIONE CORRETTA"
    echo "============================================================"
    echo ""
    echo " Problema risolto! Pronto all'uso."
    echo ""
}

show_menu() {
    clear
    echo "============================================================"
    echo " MENU PRINCIPALE"
    echo "============================================================"
    echo ""
    echo "1. TEST RAPIDO - Verifica categorie (30 sec)"
    echo "2. SCRAPING COMPLETO - Tutto il catalogo (30-60 min)"
    echo "3. Installa dipendenze"
    echo "4. Verifica configurazione"
    echo "5. Leggi documentazione"
    echo ""
    echo "0. Esci"
    echo ""
}

check_python() {
    if ! command -v python3 &> /dev/null; then
        echo "ERRORE: Python 3 non trovato!"
        echo "Installa Python 3 prima di continuare."
        exit 1
    fi
}

test_categories() {
    echo ""
    echo "Avvio test rapido..."
    python3 test_categories_quick.py
    echo ""
    read -p "Premi INVIO per continuare..."
}

run_scraping() {
    echo ""
    echo "============================================================"
    echo " ATTENZIONE: Lo scraping completo richiede 30-60 minuti!"
    echo "============================================================"
    read -p "Sei sicuro? (digita SI): " confirm
    
    if [ "$confirm" != "SI" ]; then
        echo "Annullato."
        read -p "Premi INVIO..."
        return
    fi
    
    echo ""
    echo "Avvio scraping completo..."
    python3 hidros_scraper_FIXED.py
    echo ""
    read -p "Premi INVIO per continuare..."
}

install_deps() {
    echo ""
    echo "Installazione dipendenze..."
    python3 -m pip install --upgrade pip
    pip3 install selenium pandas requests beautifulsoup4 openpyxl
    echo ""
    echo "Installazione completata!"
    read -p "Premi INVIO per continuare..."
}

verify_config() {
    echo ""
    echo "Verifica configurazione..."
    python3 -c "
import json
c = json.load(open('config.json'))
print('\nCredenziali:')
print(f'  Email: {c[\"credentials\"][\"email\"]}')
print(f'  Password: {\"*\"*len(c[\"credentials\"][\"password\"])}')
print(f'\nURL: {c[\"site\"][\"base_url\"]}')
"
    echo ""
    read -p "Premi INVIO per continuare..."
}

show_docs() {
    echo ""
    cat README.md
    echo ""
    read -p "Premi INVIO per continuare..."
}

# Main
check_python
show_banner

while true; do
    show_menu
    read -p "Scegli un'opzione: " choice
    
    case $choice in
        1) test_categories ;;
        2) run_scraping ;;
        3) install_deps ;;
        4) verify_config ;;
        5) show_docs ;;
        0) 
            echo ""
            echo "Arrivederci!"
            exit 0
            ;;
        *)
            echo "Opzione non valida!"
            read -p "Premi INVIO..."
            ;;
    esac
done
