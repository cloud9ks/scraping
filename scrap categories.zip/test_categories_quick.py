#!/usr/bin/env python3
"""
TEST RAPIDO - Verifica estrazione categorie
Mostra le prime 20 categorie senza fare scraping completo
"""

import sys
import time
from hidros_scraper_FIXED import HidrosScraper

def test_categories():
    print("\n" + "="*60)
    print(" TEST RAPIDO ESTRAZIONE CATEGORIE - SENZA FILTRI")
    print("="*60)
    
    scraper = HidrosScraper("config.json")
    
    try:
        # Setup browser
        scraper.setup_driver()
        
        # Login
        if not scraper.login():
            print("❌ Login fallito")
            return False
        
        # Estrai solo categorie (senza scraping prodotti)
        if not scraper.extract_categories_from_mobile_nav():
            print("❌ Nessuna categoria trovata")
            return False
        
        # Mostra risultati
        print("\n" + "="*60)
        print(f"✅ TROVATE {len(scraper.categories)} CATEGORIE!")
        print("="*60)
        
        if scraper.categories:
            print("\nPrime 20 categorie:")
            for i, cat in enumerate(scraper.categories[:20], 1):
                parent = cat['parent'] if cat['parent'] != 'ROOT' else ''
                parent_str = f"[{parent}] " if parent else ""
                print(f"  {i}. {parent_str}{cat['name']}")
                print(f"      → {cat['url'][:80]}")
        
        print("\n" + "="*60)
        print("TEST COMPLETATO!")
        print("="*60)
        return True
        
    except Exception as e:
        print(f"\n❌ ERRORE: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        if scraper.driver:
            print("\n🔒 Chiudo browser...")
            scraper.driver.quit()

if __name__ == "__main__":
    success = test_categories()
    sys.exit(0 if success else 1)
