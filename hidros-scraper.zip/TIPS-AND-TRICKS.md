# 💡 Tips & Tricks - HidrosPoint Scraper

## 🎯 Best Practices per Questo Sito

### 1. Menu a Tendina Problematici

Il sito HidrosPoint usa menu JavaScript dinamici che possono essere difficili da gestire. Ecco le strategie:

#### Strategia A: Hover + Attesa
```javascript
await page.hover('.menu-item');
await page.waitForTimeout(2000); // Attendi che si apra
```

#### Strategia B: Click Forzato
```javascript
await page.evaluate(() => {
    document.querySelector('.menu-item').click();
});
```

#### Strategia C: Movimento Mouse Naturale
```javascript
const box = await element.boundingBox();
await page.mouse.move(box.x + box.width/2, box.y + box.height/2);
await page.waitForTimeout(1500);
```

### 2. Gestione dei Prodotti

I prodotti sono visualizzati in tabelle (TR). Selettori chiave:

```javascript
// Prodotti principali
'tr[class*="product"]'

// Codice prodotto
'[class*="MODELLO"]'

// Prezzo
'[class*="PREZZO"]' 

// Disponibilità
'[class*="DISPONIBILE"]'
```

### 3. Paginazione

Se ci sono più pagine:

```javascript
async function scrapePaginatedCategory(url) {
    let page = 1;
    let hasMore = true;
    
    while (hasMore) {
        await this.page.goto(`${url}?page=${page}`);
        const products = await this.extractProducts();
        
        if (products.length === 0) {
            hasMore = false;
        } else {
            this.allProducts.push(...products);
            page++;
        }
    }
}
```

### 4. Ottimizzazione Performance

#### Cache delle Immagini (disabilita se non servono)
```javascript
await page.setRequestInterception(true);
page.on('request', (request) => {
    if (request.resourceType() === 'image') {
        request.abort();
    } else {
        request.continue();
    }
});
```

#### Blocco Risorse Non Necessarie
```javascript
const blockedResources = ['font', 'image', 'media'];
page.on('request', (request) => {
    if (blockedResources.includes(request.resourceType())) {
        request.abort();
    } else {
        request.continue();
    }
});
```

### 5. Gestione Errori Robusti

```javascript
async function safeScrape(fn, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            return await fn();
        } catch (error) {
            console.log(`Tentativo ${i + 1}/${retries} fallito`);
            if (i === retries - 1) throw error;
            await this.page.waitForTimeout(3000);
        }
    }
}
```

## 🔍 Selettori Specifici HidrosPoint

### Login
- Email: `input[type="email"]` o `input[name="email"]`
- Password: `input[type="password"]`
- Submit: `button[type="submit"]`

### Navigazione
- Menu principale: `nav a`, `[class*="menu"] a`
- Sottomenu: `.dropdown-menu a`, `[class*="submenu"] a`
- Breadcrumb: `[class*="breadcrumb"]`

### Prodotti
- Container: `tr[class*="product"]`
- Codice: `[class*="MODELLO"]`, `[class*="code"]`
- Nome: Prima colonna o `[class*="title"]`
- Prezzo: `[class*="PREZZO"]`, formato: €X,XXXX
- Disponibilità: `[class*="DISPONIBILE"]` (verde = disponibile)
- Brand: Logo immagine con `alt` attribute
- Quantità: Numero verde prima di "DISPONIBILE"

### Brand Comuni
- BUGATTI (logo verde)
- ICMA (logo blu)
- Far
- Itap
- Geberit

## 🚨 Problemi Noti e Soluzioni

### Problema 1: Session Timeout
**Sintomo:** Dopo 30 minuti, il login scade

**Soluzione:**
```javascript
async function refreshSession() {
    const currentUrl = this.page.url();
    await this.page.goto(BASE_URL);
    await this.page.goto(currentUrl);
}

// Usa ogni 20 minuti
setInterval(() => refreshSession(), 20 * 60 * 1000);
```

### Problema 2: Lazy Loading
**Sintomo:** Non tutti i prodotti vengono caricati

**Soluzione:**
```javascript
async function loadAllProducts() {
    let previousHeight = 0;
    let currentHeight = await page.evaluate('document.body.scrollHeight');
    
    while (previousHeight !== currentHeight) {
        await page.evaluate('window.scrollTo(0, document.body.scrollHeight)');
        await page.waitForTimeout(2000);
        previousHeight = currentHeight;
        currentHeight = await page.evaluate('document.body.scrollHeight');
    }
}
```

### Problema 3: CAPTCHA
**Sintomo:** Compare un captcha dopo molte richieste

**Soluzione:**
- Aumenta le pause tra le richieste
- Usa user agent realistici
- Limita a max 20-30 richieste al minuto
- Implementa stealth mode (puppeteer-extra-plugin-stealth)

### Problema 4: Prezzi Non Visibili
**Sintomo:** Prezzi non estratti correttamente

**Soluzione:**
```javascript
const priceText = await page.evaluate(() => {
    const priceEl = document.querySelector('[class*="PREZZO"]');
    return priceEl ? priceEl.textContent : '';
});

// Parsing robusto
const price = priceText
    .replace('€', '')
    .replace(/\s/g, '')
    .replace(',', '.')
    .trim();
```

## 📊 Struttura Dati Ottimale

```javascript
{
    // IDs
    "internalId": "auto-generated-uuid",
    "productCode": "B8101",
    "ean": "",  // Se disponibile
    
    // Info base
    "name": "VALVOLA ARRESTO A SFERA...",
    "brand": "BUGATTI",
    "category": "Valvole Arresto Sfera",
    "subcategory": "Con leva femmina-femmina",
    
    // Pricing
    "price": 6.5377,
    "currency": "EUR",
    "priceFormatted": "€6,54",
    
    // Disponibilità
    "inStock": true,
    "quantity": 781,
    "availability": "DISPONIBILE",
    
    // Technical specs
    "size": "1\"",
    "material": "Ottone",
    "connectionType": "Femmina-Femmina",
    
    // Media
    "images": ["https://..."],
    "thumbnail": "https://...",
    
    // Links
    "productUrl": "https://b2b.hidros.com/...",
    "categoryUrl": "https://...",
    
    // Metadata
    "scrapedAt": "2025-11-04T10:30:00Z",
    "lastUpdated": "2025-11-04T10:30:00Z",
    "source": "hidros-b2b"
}
```

## 🎨 Miglioramenti Futuri

### 1. Database Integration
```javascript
const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    code: { type: String, unique: true, required: true },
    name: String,
    price: Number,
    // ... altri campi
    history: [{
        price: Number,
        date: Date
    }]
});

// Traccia cambiamenti prezzo
```

### 2. API REST
```javascript
const express = require('express');
const app = express();

app.get('/api/products', async (req, res) => {
    const products = await getProducts();
    res.json(products);
});

app.get('/api/products/:code', async (req, res) => {
    const product = await getProductByCode(req.params.code);
    res.json(product);
});
```

### 3. Scheduling Automatico
```javascript
const cron = require('node-cron');

// Scraping giornaliero alle 2:00 AM
cron.schedule('0 2 * * *', async () => {
    console.log('Starting scheduled scraping...');
    const scraper = new HidrosScraper();
    await scraper.scrapeAll();
});
```

### 4. Notifiche
```javascript
// Telegram
async function sendTelegramNotification(message) {
    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
    await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: CHAT_ID,
            text: message
        })
    });
}

// Usa dopo lo scraping
await sendTelegramNotification(`Scraping completato! ${productsCount} prodotti estratti.`);
```

### 5. Diff Tool
```javascript
// Confronta due scraping per trovare differenze
function compareScrapings(old, new) {
    const changes = {
        added: [],
        removed: [],
        priceChanged: []
    };
    
    // Logica di confronto...
    
    return changes;
}
```

## 🔒 Sicurezza

### Non Committare Credenziali
```javascript
// Usa variabili d'ambiente
require('dotenv').config();

const LOGIN_EMAIL = process.env.HIDROS_EMAIL;
const LOGIN_PASSWORD = process.env.HIDROS_PASSWORD;
```

File `.env`:
```
HIDROS_EMAIL=info@nextradeitalia.com
HIDROS_PASSWORD=05391463
```

### Rate Limiting
```javascript
class RateLimiter {
    constructor(maxPerMinute) {
        this.max = maxPerMinute;
        this.requests = [];
    }
    
    async waitIfNeeded() {
        const now = Date.now();
        this.requests = this.requests.filter(t => now - t < 60000);
        
        if (this.requests.length >= this.max) {
            const oldestRequest = this.requests[0];
            const waitTime = 60000 - (now - oldestRequest);
            await new Promise(resolve => setTimeout(resolve, waitTime));
        }
        
        this.requests.push(now);
    }
}

// Uso
const limiter = new RateLimiter(30);
await limiter.waitIfNeeded();
await scrapeCategory();
```

## 📈 Monitoring

```javascript
const stats = {
    startTime: Date.now(),
    categoriesScraped: 0,
    productsScraped: 0,
    errors: 0,
    warnings: 0
};

function logProgress() {
    const elapsed = (Date.now() - stats.startTime) / 1000;
    const rate = stats.productsScraped / elapsed;
    
    console.log(`
    ⏱️  Tempo: ${elapsed.toFixed(0)}s
    📦 Prodotti: ${stats.productsScraped}
    📁 Categorie: ${stats.categoriesScraped}
    ⚡ Rate: ${rate.toFixed(2)} prod/sec
    ⚠️  Errori: ${stats.errors}
    `);
}

setInterval(logProgress, 30000); // Ogni 30 secondi
```

---

## 🎓 Risorse Utili

- [Puppeteer Docs](https://pptr.dev/)
- [CSS Selectors Reference](https://www.w3schools.com/cssref/css_selectors.asp)
- [XPath Cheatsheet](https://devhints.io/xpath)
- [Node.js Best Practices](https://github.com/goldbergyoni/nodebestpractices)

---

**Happy Scraping! 🕷️**
