#!/usr/bin/env python3
"""
Hidros B2B Scraper - Versione con Dropdown Menu
Gestisce i menu dropdown per estrarre le categorie
"""

import time
import json
import os
import sys
import sqlite3
import requests
from pathlib import Path
from datetime import datetime
from urllib.parse import urljoin, urlparse

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, NoSuchElementException, StaleElementReferenceException

import pandas as pd


class HidrosScraper:
    """Scraper per catalogo Hidros B2B con gestione dropdown"""
    
    def __init__(self, config_file="config.json"):
        # Carica configurazione
        print("📋 Caricamento configurazione...")
        with open(config_file, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        
        # Setup directories
        self.output_dir = Path(self.config['output']['directory'])
        self.images_dir = Path(self.config['output']['images_directory'])
        self.output_dir.mkdir(exist_ok=True)
        self.images_dir.mkdir(exist_ok=True)
        
        # Database
        self.db_path = self.config['output']['database']
        
        # Browser setup
        self.driver = None
        self.wait = None
        
        # Dati estratti
        self.products = []
        self.categories = []
        
    def setup_driver(self):
        """Inizializza il browser"""
        print("🌐 Inizializzazione browser...")
        
        options = Options()
        if self.config['options']['headless']:
            options.add_argument('--headless')
        
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument(f"user-agent={self.config['options']['user_agent']}")
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        self.driver = webdriver.Chrome(options=options)
        self.driver.maximize_window()
        self.wait = WebDriverWait(self.driver, 15)
        
        print("✓ Browser pronto")
        
    def login(self):
        """Effettua il login"""
        print("\n" + "="*60)
        print(" LOGIN")
        print("="*60)
        
        try:
            # Vai alla pagina di login
            login_url = self.config['site']['login_url']
            print(f"📍 Navigazione a: {login_url}")
            self.driver.get(login_url)
            time.sleep(self.config['delays']['page_load'])
            
            # Prendi i selettori dal config
            selectors = self.config['selectors']['login']
            email_selector = selectors['email_field']
            password_selector = selectors['password_field']
            
            print(f"🔍 Cercando campo email...")
            email_field = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, email_selector))
            )
            print("✓ Campo email trovato")
            
            print(f"🔍 Cercando campo password...")
            password_field = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, password_selector))
            )
            print("✓ Campo password trovato")
            
            # Inserisci credenziali
            email = self.config['credentials']['email']
            password = self.config['credentials']['password']
            
            print(f"⌨️  Inserimento credenziali...")
            email_field.clear()
            email_field.send_keys(email)
            time.sleep(0.5)
            
            password_field.clear()
            password_field.send_keys(password)
            time.sleep(0.5)
            
            # Trova e clicca submit button
            print(f"🔍 Cercando pulsante submit...")
            selectors_to_try = [
                "div.login-container form button",
                "form button",
            ]
            
            submit_button = None
            for selector in selectors_to_try:
                try:
                    submit_button = WebDriverWait(self.driver, 5).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    break
                except TimeoutException:
                    continue
            
            if not submit_button:
                raise Exception("Pulsante submit non trovato")
            
            print("🖱️  Click sul pulsante login...")
            submit_button.click()
            time.sleep(self.config['delays']['after_login'])
            
            # Verifica login
            current_url = self.driver.current_url
            if "login" not in current_url.lower():
                print("✅ LOGIN RIUSCITO!")
                return True
            else:
                print("⚠️  Login fallito")
                return False
                
        except Exception as e:
            print(f"❌ ERRORE durante il login: {str(e)}")
            return False
    
    def extract_categories_from_mobile_nav(self):
        """Estrae le categorie dal menu mobile (contiene tutti i link!)"""
        print("\n" + "="*60)
        print(" ESTRAZIONE CATEGORIE DA MOBILE NAV")
        print("="*60)
        
        try:
            print("⏳ Attendo caricamento menu...")
            time.sleep(3)
            
            # Aspetta che il menu mobile sia presente
            print("🔍 Cercando nav.mobile-nav...")
            mobile_nav = WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "nav.mobile-nav"))
            )
            time.sleep(2)
            print("✓ Menu mobile trovato!")
            
            # Estrai TUTTI i link dal menu mobile
            print("🔍 Estrazione link da mobile nav...")
            all_links = self.driver.find_elements(By.CSS_SELECTOR, "nav.mobile-nav a")
            print(f"✓ Trovati {len(all_links)} link totali")
            
            # Filtra e organizza i link
            print("📦 Filtraggio link validi...")
            
            current_parent = "ROOT"  # Categoria padre corrente
            
            for link in all_links:
                try:
                    href = link.get_attribute('href')
                    text = link.text.strip()
                    classes = link.get_attribute('class') or ''
                    
                    # Skip link non validi
                    if not href or href == "javascript:;" or not text or len(text) < 3:
                        continue
                    
                    # FILTRI MINIMI - esclude solo i più evidenti non-categorie
                    skip_keywords = ['/account', '/cart', '/checkout', 
                                    'facebook.com', 'instagram.com', 'twitter.com',
                                    'mailto:', 'tel:']
                    if any(keyword in href.lower() for keyword in skip_keywords):
                        continue
                    
                    # SALVA TUTTI I LINK (nessuna logica parent/child)
                    # Il nav.mobile-nav contiene tutte le categorie valide
                    if not any(cat['url'] == href for cat in self.categories):
                        self.categories.append({
                            'name': text,
                            'url': href,
                            'parent': 'ROOT'  # Tutti come root per semplicità
                        })
                    
                except Exception as e:
                    if self.config['options']['verbose']:
                        print(f"   ⚠️  Errore su link: {str(e)}")
                    continue
            
            print(f"✅ TOTALE: {len(self.categories)} categorie estratte")
            
            # Mostra prime 15
            if self.categories:
                print("\nPrime 15 categorie:")
                for i, cat in enumerate(self.categories[:15], 1):
                    print(f"  {i}. [{cat['parent']}] {cat['name'][:50]}")
            
            return len(self.categories) > 0
            
        except Exception as e:
            print(f"❌ Errore estrazione categorie: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
        """Estrae le categorie dai menu dropdown"""
        print("\n" + "="*60)
        print(" ESTRAZIONE CATEGORIE DA DROPDOWN")
        print("="*60)
        
        try:
            print("⏳ Attendo caricamento menu...")
            time.sleep(3)
            
            # Aspetta che il menu principale sia caricato
            menu = WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "nav.main-nav"))
            )
            time.sleep(2)
            print("✓ Menu principale caricato")
            
            # Trova i link dropdown del menu principale
            print("🔍 Ricerca dropdown menu...")
            dropdown_triggers = self.driver.find_elements(By.CSS_SELECTOR, "nav.main-nav a.menu-arrow")
            print(f"✓ Trovati {len(dropdown_triggers)} menu dropdown")
            
            # Per ogni dropdown
            for idx, trigger in enumerate(dropdown_triggers, 1):
                try:
                    # Ritrova l'elemento per evitare StaleElementReferenceException
                    dropdown_triggers = self.driver.find_elements(By.CSS_SELECTOR, "nav.main-nav a.menu-arrow")
                    trigger = dropdown_triggers[idx - 1]
                    
                    menu_name = trigger.text.strip()
                    if not menu_name:
                        continue
                    
                    print(f"\n📂 [{idx}/{len(dropdown_triggers)}] {menu_name}")
                    
                    # Scroll per renderlo visibile
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", trigger)
                    time.sleep(0.5)
                    
                    # Click per aprire il dropdown (o hover)
                    try:
                        # Prova hover prima (alcuni menu si aprono con hover)
                        actions = ActionChains(self.driver)
                        actions.move_to_element(trigger).perform()
                        time.sleep(1)
                        
                        # Cerca i submenu aperti
                        # Possibili selettori per i submenu
                        submenu_selectors = [
                            ".dropdown-menu a",
                            ".submenu a", 
                            ".mega-menu a",
                            "[class*='dropdown'] a",
                            "[class*='submenu'] a",
                            "nav.main-nav .dropdown-menu a",
                            "nav.mobile-nav a"  # Dal test precedente sappiamo che esiste
                        ]
                        
                        submenu_links = []
                        for sel in submenu_selectors:
                            links = self.driver.find_elements(By.CSS_SELECTOR, sel)
                            if links and len(links) > 0:
                                submenu_links = links
                                print(f"   ✓ Trovati {len(links)} link con selettore: {sel}")
                                break
                        
                        if not submenu_links:
                            # Prova a cliccare se hover non ha funzionato
                            trigger.click()
                            time.sleep(1.5)
                            
                            for sel in submenu_selectors:
                                links = self.driver.find_elements(By.CSS_SELECTOR, sel)
                                if links and len(links) > 0:
                                    submenu_links = links
                                    print(f"   ✓ Trovati {len(links)} link dopo click con: {sel}")
                                    break
                        
                        if submenu_links:
                            # Estrai link unici dal submenu
                            extracted_count = 0
                            for link in submenu_links:
                                try:
                                    href = link.get_attribute('href')
                                    text = link.text.strip()
                                    
                                    if href and text and href != "javascript:;" and len(text) > 2:
                                        # Evita duplicati
                                        if not any(cat['url'] == href for cat in self.categories):
                                            self.categories.append({
                                                'name': text,
                                                'url': href,
                                                'parent': menu_name
                                            })
                                            extracted_count += 1
                                except:
                                    continue
                            
                            print(f"   ✓ Estratte {extracted_count} sottocategorie")
                        else:
                            print(f"   ⚠️  Nessun submenu trovato")
                        
                        # Chiudi il dropdown (click da un'altra parte)
                        body = self.driver.find_element(By.TAG_NAME, "body")
                        actions = ActionChains(self.driver)
                        actions.move_to_element_with_offset(body, 0, 0).perform()
                        time.sleep(0.5)
                        
                    except Exception as e:
                        print(f"   ⚠️  Errore nell'aprire dropdown: {str(e)}")
                        continue
                    
                except StaleElementReferenceException:
                    print(f"   ⚠️  Elemento stale, riprovo...")
                    continue
                except Exception as e:
                    print(f"   ⚠️  Errore: {str(e)}")
                    continue
            
            print(f"\n✅ TOTALE: {len(self.categories)} categorie estratte")
            
            # Mostra prime 10
            if self.categories:
                print("\nPrime 10 categorie:")
                for i, cat in enumerate(self.categories[:10], 1):
                    print(f"  {i}. [{cat['parent']}] {cat['name'][:50]}")
            
            return len(self.categories) > 0
            
        except Exception as e:
            print(f"❌ Errore estrazione categorie: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def extract_products_from_category(self, category):
        """Estrae prodotti da una categoria"""
        print(f"\n📦 Categoria: {category['name'][:60]}")
        print(f"   Parent: {category['parent']}")
        print(f"   URL: {category['url'][:80]}")
        
        try:
            self.driver.get(category['url'])
            time.sleep(self.config['delays']['page_load'])
            
            # Selettori prodotti dal config
            prod_selectors = self.config['selectors']['products']
            
            # Cerca i prodotti
            product_elements = self.driver.find_elements(
                By.CSS_SELECTOR, 
                prod_selectors['product_cards']
            )
            
            if not product_elements:
                print(f"   ⚠️  Nessun prodotto trovato")
                return
            
            print(f"   Trovati {len(product_elements)} prodotti")
            
            for idx, prod_elem in enumerate(product_elements, 1):
                try:
                    # Estrai dati prodotto
                    product_data = {
                        'category': category['name'],
                        'parent_category': category['parent'],
                        'category_url': category['url'],
                        'scraped_at': datetime.now().isoformat()
                    }
                    
                    # Titolo
                    try:
                        title_elem = prod_elem.find_element(By.CSS_SELECTOR, prod_selectors['product_title'])
                        product_data['title'] = title_elem.text.strip()
                    except:
                        product_data['title'] = 'N/A'
                    
                    # Prezzo
                    try:
                        price_elem = prod_elem.find_element(By.CSS_SELECTOR, prod_selectors['product_price'])
                        product_data['price'] = price_elem.text.strip()
                    except:
                        product_data['price'] = 'N/A'
                    
                    # SKU
                    try:
                        sku_elem = prod_elem.find_element(By.CSS_SELECTOR, prod_selectors['product_sku'])
                        product_data['sku'] = sku_elem.text.strip()
                    except:
                        product_data['sku'] = 'N/A'
                    
                    # URL prodotto
                    try:
                        link_elem = prod_elem.find_element(By.CSS_SELECTOR, prod_selectors['product_links'])
                        product_data['url'] = link_elem.get_attribute('href')
                    except:
                        product_data['url'] = category['url']
                    
                    # Immagine
                    try:
                        img_elem = prod_elem.find_element(By.CSS_SELECTOR, prod_selectors['product_image'])
                        img_url = img_elem.get_attribute('src')
                        if img_url:
                            product_data['image_url'] = img_url
                            if self.config['download']['images']:
                                img_path = self.download_image(img_url, product_data.get('sku', f'prod_{idx}'))
                                product_data['image_local'] = img_path
                    except:
                        product_data['image_url'] = 'N/A'
                    
                    self.products.append(product_data)
                    
                    if self.config['options']['verbose'] and idx % 10 == 0:
                        print(f"   [{idx}/{len(product_elements)}] processati...")
                    
                except Exception as e:
                    if self.config['options']['verbose']:
                        print(f"   ⚠️  Errore prodotto {idx}: {str(e)}")
                    continue
                
                time.sleep(self.config['delays']['between_requests'])
            
            print(f"   ✓ Completato: {len([p for p in self.products if p['category'] == category['name']])} prodotti estratti")
            
        except Exception as e:
            print(f"   ❌ Errore nella categoria: {str(e)}")
    
    def download_image(self, url, filename):
        """Scarica un'immagine"""
        try:
            filename = "".join(c for c in filename if c.isalnum() or c in ('-', '_'))
            ext = Path(urlparse(url).path).suffix or '.jpg'
            filepath = self.images_dir / f"{filename}{ext}"
            
            if filepath.exists():
                return str(filepath.relative_to(self.output_dir))
            
            response = requests.get(url, timeout=self.config['download']['timeout_seconds'])
            response.raise_for_status()
            
            size_mb = len(response.content) / (1024 * 1024)
            if size_mb > self.config['download']['max_image_size_mb']:
                return None
            
            with open(filepath, 'wb') as f:
                f.write(response.content)
            
            return str(filepath.relative_to(self.output_dir))
            
        except Exception as e:
            return None
    
    def save_to_database(self):
        """Salva dati nel database SQLite"""
        print("\n💾 Salvataggio database...")
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT,
                parent_category TEXT,
                category_url TEXT,
                title TEXT,
                sku TEXT,
                price TEXT,
                url TEXT,
                image_url TEXT,
                image_local TEXT,
                scraped_at TEXT
            )
        ''')
        
        for prod in self.products:
            cursor.execute('''
                INSERT INTO products (category, parent_category, category_url, title, sku, price, url, image_url, image_local, scraped_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                prod.get('category', ''),
                prod.get('parent_category', ''),
                prod.get('category_url', ''),
                prod.get('title', ''),
                prod.get('sku', ''),
                prod.get('price', ''),
                prod.get('url', ''),
                prod.get('image_url', ''),
                prod.get('image_local', ''),
                prod.get('scraped_at', '')
            ))
        
        conn.commit()
        conn.close()
        print(f"✓ Database salvato: {self.db_path}")
    
    def save_to_excel(self):
        """Salva dati in Excel"""
        print("📊 Salvataggio Excel...")
        df = pd.DataFrame(self.products)
        excel_path = self.config['output']['excel_file']
        df.to_excel(excel_path, index=False, engine='openpyxl')
        print(f"✓ Excel salvato: {excel_path}")
    
    def save_to_csv(self):
        """Salva dati in CSV"""
        print("📄 Salvataggio CSV...")
        df = pd.DataFrame(self.products)
        csv_path = self.config['output']['csv_file']
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"✓ CSV salvato: {csv_path}")
    
    def print_statistics(self):
        """Mostra statistiche"""
        print("\n" + "="*60)
        print(" STATISTICHE FINALI")
        print("="*60)
        print(f"Categorie: {len(self.categories)}")
        print(f"Prodotti:  {len(self.products)}")
        
        if self.products:
            df = pd.DataFrame(self.products)
            print("\nProdotti per categoria principale:")
            for cat, count in df['parent_category'].value_counts().head(10).items():
                print(f"  • {cat}: {count}")
    
    def run(self):
        """Esegue lo scraping completo"""
        print("\n" + "="*60)
        print(" HIDROS B2B SCRAPER - MOBILE NAV VERSION")
        print("="*60)
        
        try:
            self.setup_driver()
            
            if not self.login():
                print("\n❌ Login fallito.")
                return False
            
            if not self.extract_categories_from_mobile_nav():
                print("\n❌ Nessuna categoria trovata.")
                return False
            
            # Limita le categorie se specificato (per test)
            max_categories = self.config.get('max_categories_to_scrape', None)
            if max_categories:
                print(f"\n⚠️  Modalità TEST: Scraping solo prime {max_categories} categorie")
                categories_to_scrape = self.categories[:max_categories]
            else:
                categories_to_scrape = self.categories
            
            print(f"\n🔄 Scraping di {len(categories_to_scrape)} categorie...")
            for idx, category in enumerate(categories_to_scrape, 1):
                print(f"\n[{idx}/{len(categories_to_scrape)}]")
                self.extract_products_from_category(category)
                time.sleep(self.config['delays']['between_requests'])
            
            if self.products:
                self.save_to_database()
                self.save_to_excel()
                self.save_to_csv()
                self.print_statistics()
                
                print("\n✅ SCRAPING COMPLETATO CON SUCCESSO!")
                return True
            else:
                print("\n⚠️  Nessun prodotto estratto")
                return False
                
        except Exception as e:
            print(f"\n❌ ERRORE FATALE: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
            
        finally:
            if self.driver:
                print("\n🔒 Chiusura browser...")
                self.driver.quit()


def main():
    config_file = "config.json"
    
    if not os.path.exists(config_file):
        print(f"❌ File {config_file} non trovato!")
        sys.exit(1)
    
    scraper = HidrosScraper(config_file)
    success = scraper.run()
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()