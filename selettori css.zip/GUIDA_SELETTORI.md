# 🔧 Guida alla Modifica dei Selettori CSS

Se il sito HidrosPoint cambia struttura e lo scraper non funziona più, segui questa guida per aggiornare i selettori CSS.

---

## 🎯 Cos'è un Selettore CSS?

Un selettore CSS è come un "indirizzo" per trovare elementi nella pagina web.

Esempi:
- `.product-name` → trova elementi con class="product-name"
- `#price` → trova elemento con id="price"
- `table tbody tr` → trova tutte le righe dentro una tabella
- `[class*="product"]` → trova elementi con "product" nel nome della classe

---

## 🛠️ Come Trovare i Selettori Giusti

### Metodo 1: Inspector Tool (Consigliato)

1. **Apri il sito** e fai login
2. **Premi F12** per aprire DevTools
3. **Click sull'icona** 🔍 "Select element" (in alto a sinistra dei DevTools)
4. **Click sull'elemento** che vuoi (es. il nome del prodotto)
5. Nel pannello Elements/Inspector vedrai l'HTML evidenziato
6. **Right-click sull'elemento** → Copy → Copy selector
7. Incolla il selettore nel codice!

### Metodo 2: Manuale

1. Apri DevTools (F12)
2. Vai su Elements/Inspector
3. Cerca l'elemento che ti interessa
4. Guarda gli attributi `class` e `id`
5. Crea il selettore:
   - Se ha `class="product-name"` → usa `.product-name`
   - Se ha `id="price"` → usa `#price`
   - Se ha `class="item-product-123"` → usa `[class*="product"]`

---

## 📝 Dove Modificare i Selettori

### Script Console (hidrospoint_scraper_console.js)

Cerca queste righe e modificale:

```javascript
// PRODOTTI - Cerca le righe prodotto
const productRows = document.querySelectorAll('MODIFICA_QUI');

// Esempi da provare:
// 'table tbody tr'
// '.product-item'
// '[class*="product-row"]'
// '.catalog-item'
```

```javascript
// CODICE PRODOTTO
const productCode = row.querySelector('MODIFICA_QUI');

// Esempi:
// '[class*="model"]'
// '.product-code'
// '.modello'
// 'td[data-label="Codice"]'
```

```javascript
// NOME PRODOTTO
const productName = row.querySelector('MODIFICA_QUI');

// Esempi:
// 'h3'
// 'h4'
// '.product-name'
// '[class*="title"]'
```

```javascript
// PREZZO
const price = row.querySelector('MODIFICA_QUI');

// Esempi:
// '[class*="price"]'
// '.prezzo'
// '.product-price'
// 'td[data-label="Prezzo"]'
```

### Script Puppeteer (hidrospoint_scraper_puppeteer.js)

Cerca la sezione `CONFIG.selectors` e modifica:

```javascript
selectors: {
    // Login (di solito non cambiano)
    loginUsername: 'input[name="username"]',
    loginPassword: 'input[name="password"]',
    loginButton: 'button[type="submit"]',
    
    // CATEGORIE
    categoryLinks: 'MODIFICA_QUI',
    // Prova: 'a[href*="category"]'
    
    // PRODOTTI
    productRows: 'MODIFICA_QUI',
    // Prova: 'table tbody tr' o '.product-item'
    
    productCode: 'MODIFICA_QUI',
    // Prova: '[class*="model"]' o '.product-code'
    
    productName: 'MODIFICA_QUI',
    // Prova: 'h3' o '[class*="name"]'
    
    productPrice: 'MODIFICA_QUI',
    // Prova: '[class*="price"]' o '.prezzo'
    
    productAvailability: 'MODIFICA_QUI',
    // Prova: '[class*="disponi"]' o '.stock'
    
    productImage: 'img',
    
    productBrand: 'MODIFICA_QUI',
    // Prova: '[class*="brand"]' o '.marca'
}
```

---

## 🧪 Come Testare i Selettori

### Test nella Console del Browser

1. Apri il sito e fai login
2. Premi F12 → Console
3. Prova il selettore:

```javascript
// Conta quanti elementi trova
document.querySelectorAll('TUO_SELETTORE').length

// Mostra il primo elemento
document.querySelector('TUO_SELETTORE')

// Mostra il testo del primo elemento
document.querySelector('TUO_SELETTORE')?.textContent
```

Esempi pratici:

```javascript
// Quante righe prodotto ci sono?
document.querySelectorAll('table tbody tr').length
// Output: 25 ✅ (buono!)

// Trova i codici prodotto
document.querySelectorAll('[class*="model"]').length
// Output: 25 ✅ (uno per prodotto!)

// Vedi il primo codice
document.querySelector('[class*="model"]').textContent
// Output: "B3003/8" ✅ (perfetto!)
```

### Test con lo Script di Test

```bash
# Modifica prima USERNAME e PASSWORD in test_hidrospoint.js
node test_hidrospoint.js
```

Lo script ti dirà esattamente:
- ✅ Quali selettori funzionano
- ❌ Quali selettori non funzionano
- 📸 Crea uno screenshot per debug

---

## 💡 Trucchi e Pattern Comuni

### Pattern 1: Selettori Flessibili

Usa `[class*="keyword"]` per trovare classi che contengono una parola:

```javascript
// Trova elementi con "product" nella classe
'[class*="product"]'

// Esempi che matchano:
// class="product-item"
// class="item-product"
// class="product"
```

### Pattern 2: Multiple Selector (Fallback)

Prova più selettori contemporaneamente:

```javascript
const price = row.querySelector('[class*="price"], .prezzo, .product-price');
```

Puppeteer proverà in ordine finché uno funziona.

### Pattern 3: Selettori Relativi

Parti da un elemento padre:

```javascript
// Trova tutti i TD dentro la riga
const cells = row.querySelectorAll('td');

// Prendi il terzo TD (indice 2)
const price = cells[2]?.textContent;
```

### Pattern 4: Attributi Data

Molti siti moderni usano `data-*`:

```javascript
// Cerca per attributo data
'[data-product-code]'
'[data-price]'
'td[data-label="Prezzo"]'
```

---

## 🔍 Debug Avanzato

### Vedi la Struttura HTML di un Prodotto

Console browser:

```javascript
// Prendi il primo prodotto
const firstProduct = document.querySelector('table tbody tr');

// Vedi l'HTML completo
console.log(firstProduct.innerHTML);

// O solo la struttura
console.log(firstProduct.outerHTML.substring(0, 500));
```

### Testa Tutti i Possibili Selettori

```javascript
// Prova vari selettori per le righe prodotto
const selectors = [
    'table tbody tr',
    '.product-row',
    '.product-item',
    '[class*="product"]',
    '.catalog-item',
    '[data-product]'
];

selectors.forEach(sel => {
    const count = document.querySelectorAll(sel).length;
    console.log(`${sel}: ${count} elementi`);
});
```

### Estrai Tutto da un Elemento

```javascript
// Prendi il primo prodotto
const prod = document.querySelector('table tbody tr');

// Estrai TUTTI i text content
Array.from(prod.querySelectorAll('*'))
    .map(el => el.textContent.trim())
    .filter(text => text.length > 0 && text.length < 100)
    .forEach(text => console.log(text));
```

---

## ⚠️ Problemi Comuni

### ❌ "Cannot read property 'textContent' of null"

**Problema**: Il selettore non trova niente
**Soluzione**: 
1. Verifica che l'elemento esista
2. Usa il test nella console: `document.querySelector('TUO_SELETTORE')`
3. Aggiusta il selettore

### ❌ Trova troppe cose o cose sbagliate

**Problema**: Selettore troppo generico (es. `'div'`)
**Soluzione**: 
1. Rendi il selettore più specifico
2. Usa classi o attributi unici
3. Combina più selettori: `.parent .child`

### ❌ Il sito carica i dati dopo

**Problema**: JavaScript carica i prodotti dopo che la pagina è aperta
**Soluzione**: 
1. Aumenta `waitTime` in CONFIG
2. Aggiungi `await sleep(3000)` prima di scrapare
3. Aspetta un elemento specifico: `await page.waitForSelector('.product')`

---

## 📚 Risorse Utili

- [MDN CSS Selectors](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Selectors)
- [CSS Selector Tester](https://www.w3schools.com/cssref/trysel.asp)

---

## 🆘 Ancora Problemi?

1. **Esegui il test script**: `node test_hidrospoint.js`
2. **Guarda lo screenshot** generato: `test_screenshot.png`
3. **Apri DevTools** e ispeziona manualmente
4. **Usa la console** per testare i selettori uno per uno

Se tutto fallisce, il sito potrebbe aver cambiato completamente struttura. In quel caso:
1. Fai uno screenshot della nuova struttura
2. Usa DevTools per esplorare l'HTML
3. Ricrea i selettori da zero seguendo questa guida

---

**Buon debug! 🔧**
