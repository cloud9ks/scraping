/**
 * HIDROSPOINT B2B SCRAPER - Puppeteer Version
 * 
 * INSTALLAZIONE:
 * npm install puppeteer
 * 
 * USO:
 * 1. Inserisci le tue credenziali nelle variabili USERNAME e PASSWORD
 * 2. Esegui: node hidrospoint_scraper_puppeteer.js
 * 
 * OPPURE con sessione manuale:
 * 1. Commenta la sezione di login automatico
 * 2. Fai login manualmente e riutilizza i cookies
 */

const puppeteer = require('puppeteer');
const fs = require('fs');

// ============ CONFIGURAZIONE ============
const CONFIG = {
    baseUrl: 'https://b2b.hidros.com',
    loginUrl: 'https://b2b.hidros.com/login',
    startUrl: 'https://b2b.hidros.com/shop?category=10010001&category_detail=VALVOLE%20ARRESTO%20A%20SFERA&tab_name=VALVOLE%20ARRESTO%20A%20SFERA',
    
    // Inserisci le tue credenziali (oppure usa variabili d'ambiente)
    credentials: {
        username: process.env.HIDROS_USERNAME || 'TUO_USERNAME',
        password: process.env.HIDROS_PASSWORD || 'TUA_PASSWORD'
    },
    
    // Opzioni scraping
    waitTime: 2000,  // Tempo di attesa tra le pagine (ms)
    headless: false, // Metti true per eseguire senza finestra browser
    slowMo: 100,     // Rallenta le azioni per debug
    
    // Selettori (adatta in base alla struttura del sito)
    selectors: {
        loginUsername: 'input[name="username"], input[type="email"], #username',
        loginPassword: 'input[name="password"], input[type="password"], #password',
        loginButton: 'button[type="submit"], .btn-login, input[type="submit"]',
        
        // Menu e categorie
        mainMenu: '.mega-menu, [class*="menu"], nav',
        categoryLinks: 'a[href*="category"]',
        
        // Prodotti
        productRows: 'table tbody tr, .product-item, [class*="product-row"]',
        productCode: '[class*="model"], .modello, [class*="codice"]',
        productName: '[class*="name"], [class*="title"], h3, h4',
        productPrice: '[class*="price"], [class*="prezzo"]',
        productAvailability: '[class*="disponi"], [class*="stock"]',
        productImage: 'img',
        productBrand: '[class*="brand"], [class*="marca"]',
        
        // Sidebar
        brands: '.sidebar a, [class*="marchi"] a',
        
        // Paginazione
        nextPage: '.pagination .next, [class*="next-page"]',
    },
    
    // Output
    outputDir: './hidros_scraping_output',
    outputFormat: 'both' // 'json', 'csv', or 'both'
};

// ============ FUNZIONI UTILITY ============

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function sanitizeFilename(name) {
    return name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
}

function saveJSON(data, filename) {
    const filepath = `${CONFIG.outputDir}/${filename}`;
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
    console.log(`✅ Salvato JSON: ${filepath}`);
}

function saveCSV(products, filename) {
    if (!products || products.length === 0) {
        console.warn('⚠️ Nessun prodotto da salvare in CSV');
        return;
    }

    const headers = ['Codice', 'Nome', 'Prezzo', 'Disponibilità', 'Marca', 'Categoria', 'URL', 'Immagine'];
    const rows = [headers.join(',')];

    products.forEach(product => {
        const row = [
            `"${(product.code || '').replace(/"/g, '""')}"`,
            `"${(product.name || '').replace(/"/g, '""')}"`,
            `"${(product.price || '').replace(/"/g, '""')}"`,
            `"${(product.availability || '').replace(/"/g, '""')}"`,
            `"${(product.brand || '').replace(/"/g, '""')}"`,
            `"${(product.category || '').replace(/"/g, '""')}"`,
            `"${(product.url || '').replace(/"/g, '""')}"`,
            `"${(product.image || '').replace(/"/g, '""')}"`
        ];
        rows.push(row.join(','));
    });

    const filepath = `${CONFIG.outputDir}/${filename}`;
    fs.writeFileSync(filepath, rows.join('\n'), 'utf8');
    console.log(`✅ Salvato CSV: ${filepath}`);
}

// ============ SCRAPER ============

class HidrosPointScraper {
    constructor() {
        this.browser = null;
        this.page = null;
        this.results = {
            scrapingDate: new Date().toISOString(),
            categories: [],
            products: [],
            brands: [],
            totalProducts: 0
        };
    }

    async init() {
        console.log('🚀 Inizializzazione browser...');
        
        // Crea directory output
        if (!fs.existsSync(CONFIG.outputDir)) {
            fs.mkdirSync(CONFIG.outputDir, { recursive: true });
        }

        this.browser = await puppeteer.launch({
            headless: CONFIG.headless,
            slowMo: CONFIG.slowMo,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-web-security'
            ]
        });

        this.page = await this.browser.newPage();
        
        // Imposta viewport
        await this.page.setViewport({ width: 1920, height: 1080 });
        
        // Imposta user agent
        await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        
        console.log('✅ Browser inizializzato');
    }

    async login() {
        console.log('🔐 Tentativo di login...');
        
        try {
            await this.page.goto(CONFIG.loginUrl, { 
                waitUntil: 'networkidle2',
                timeout: 30000 
            });

            // Aspetta il form di login
            await this.page.waitForSelector(CONFIG.selectors.loginUsername, { timeout: 10000 });

            // Inserisci credenziali
            await this.page.type(CONFIG.selectors.loginUsername, CONFIG.credentials.username);
            await this.page.type(CONFIG.selectors.loginPassword, CONFIG.credentials.password);

            // Click sul bottone di login
            await Promise.all([
                this.page.click(CONFIG.selectors.loginButton),
                this.page.waitForNavigation({ waitUntil: 'networkidle2' })
            ]);

            // Verifica se il login è riuscito
            const currentUrl = this.page.url();
            if (currentUrl.includes('login')) {
                throw new Error('Login fallito - controlla le credenziali');
            }

            console.log('✅ Login effettuato con successo');
            
            // Salva i cookies per sessioni future
            const cookies = await this.page.cookies();
            fs.writeFileSync(`${CONFIG.outputDir}/cookies.json`, JSON.stringify(cookies, null, 2));
            console.log('💾 Cookies salvati');
            
        } catch (error) {
            console.error('❌ Errore durante il login:', error.message);
            throw error;
        }
    }

    async loadCookies() {
        const cookiesPath = `${CONFIG.outputDir}/cookies.json`;
        if (fs.existsSync(cookiesPath)) {
            console.log('🍪 Caricamento cookies salvati...');
            const cookies = JSON.parse(fs.readFileSync(cookiesPath));
            await this.page.setCookie(...cookies);
            console.log('✅ Cookies caricati');
            return true;
        }
        return false;
    }

    async scrapeCategories() {
        console.log('📂 Scraping categorie...');
        
        try {
            // Vai alla pagina principale delle categorie
            await this.page.goto(`${CONFIG.baseUrl}/shop`, { 
                waitUntil: 'networkidle2',
                timeout: 30000 
            });

            await sleep(2000);

            // Estrai tutte le categorie
            const categories = await this.page.evaluate((selectors) => {
                const links = document.querySelectorAll(selectors.categoryLinks);
                const categoriesSet = new Set();
                
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    const text = link.textContent.trim();
                    
                    if (href && text && href.includes('category') && text.length > 2) {
                        categoriesSet.add(JSON.stringify({
                            name: text,
                            url: href.startsWith('http') ? href : window.location.origin + href
                        }));
                    }
                });
                
                return Array.from(categoriesSet).map(c => JSON.parse(c));
            }, CONFIG.selectors);

            this.results.categories = categories;
            console.log(`✅ Trovate ${categories.length} categorie`);
            
            return categories;
            
        } catch (error) {
            console.error('❌ Errore nello scraping delle categorie:', error.message);
            return [];
        }
    }

    async scrapeBrands() {
        console.log('🏷️ Scraping marchi...');
        
        try {
            const brands = await this.page.evaluate((selectors) => {
                const brandElements = document.querySelectorAll(selectors.brands);
                return Array.from(brandElements).map(el => ({
                    name: el.textContent.trim(),
                    count: el.querySelector('[class*="count"]')?.textContent.trim() || null
                })).filter(b => b.name && b.name.length > 1);
            }, CONFIG.selectors);

            this.results.brands = brands;
            console.log(`✅ Trovati ${brands.length} marchi`);
            
            return brands;
            
        } catch (error) {
            console.error('❌ Errore nello scraping dei marchi:', error.message);
            return [];
        }
    }

    async scrapeProductsFromPage(categoryName = '') {
        console.log(`🛍️ Scraping prodotti${categoryName ? ` da categoria: ${categoryName}` : ''}...`);
        
        try {
            // Aspetta che i prodotti siano caricati
            await this.page.waitForSelector(CONFIG.selectors.productRows, { timeout: 10000 });
            await sleep(1000);

            const products = await this.page.evaluate((selectors, category) => {
                const productElements = document.querySelectorAll(selectors.productRows);
                const products = [];

                productElements.forEach((element, index) => {
                    try {
                        const code = element.querySelector(selectors.productCode)?.textContent.trim();
                        const name = element.querySelector(selectors.productName)?.textContent.trim();
                        const price = element.querySelector(selectors.productPrice)?.textContent.trim();
                        const availability = element.querySelector(selectors.productAvailability)?.textContent.trim();
                        const image = element.querySelector(selectors.productImage)?.src;
                        const brand = element.querySelector(selectors.productBrand)?.textContent.trim();

                        // Estrai specifiche da tutte le celle
                        const specs = {};
                        const cells = element.querySelectorAll('td');
                        cells.forEach(cell => {
                            const label = cell.getAttribute('data-label') || cell.className;
                            const value = cell.textContent.trim();
                            if (label && value && value.length < 100) {
                                specs[label] = value;
                            }
                        });

                        if (code || name || price) {
                            products.push({
                                code: code || `PRODUCT_${index}`,
                                name: name || 'N/A',
                                price: price || null,
                                availability: availability || null,
                                brand: brand || null,
                                image: image || null,
                                category: category,
                                specs: specs,
                                url: window.location.href
                            });
                        }
                    } catch (error) {
                        console.warn(`Errore prodotto ${index}:`, error);
                    }
                });

                return products;
            }, CONFIG.selectors, categoryName);

            console.log(`✅ Trovati ${products.length} prodotti`);
            return products;
            
        } catch (error) {
            console.error('❌ Errore nello scraping dei prodotti:', error.message);
            return [];
        }
    }

    async scrapeCategory(category, index, total) {
        console.log(`\n[${index + 1}/${total}] 📂 Processando: ${category.name}`);
        
        try {
            await this.page.goto(category.url, { 
                waitUntil: 'networkidle2',
                timeout: 30000 
            });

            await sleep(CONFIG.waitTime);

            // Scraping marchi (solo dalla prima categoria)
            if (index === 0) {
                await this.scrapeBrands();
            }

            // Scraping prodotti
            const products = await this.scrapeProductsFromPage(category.name);
            
            // Aggiungi ai risultati
            this.results.products.push(...products);
            this.results.totalProducts += products.length;

            // Salva checkpoint ogni 5 categorie
            if ((index + 1) % 5 === 0) {
                saveJSON(this.results, `checkpoint_${index + 1}.json`);
            }

            console.log(`✅ Categoria completata: ${products.length} prodotti`);
            
        } catch (error) {
            console.error(`❌ Errore nella categoria ${category.name}:`, error.message);
        }
    }

    async scrapeAll() {
        console.log('\n🚀 Inizio scraping completo...\n');
        
        try {
            // Ottieni tutte le categorie
            const categories = await this.scrapeCategories();
            
            if (categories.length === 0) {
                console.warn('⚠️ Nessuna categoria trovata');
                return;
            }

            // Scraping di ogni categoria
            for (let i = 0; i < categories.length; i++) {
                await this.scrapeCategory(categories[i], i, categories.length);
                await sleep(CONFIG.waitTime);
            }

            console.log('\n🎉 SCRAPING COMPLETATO!');
            console.log(`📊 Statistiche finali:`);
            console.log(`   - Categorie: ${this.results.categories.length}`);
            console.log(`   - Marchi: ${this.results.brands.length}`);
            console.log(`   - Prodotti totali: ${this.results.totalProducts}`);

            // Salva risultati finali
            const timestamp = Date.now();
            
            if (CONFIG.outputFormat === 'json' || CONFIG.outputFormat === 'both') {
                saveJSON(this.results, `hidrospoint_completo_${timestamp}.json`);
            }
            
            if (CONFIG.outputFormat === 'csv' || CONFIG.outputFormat === 'both') {
                saveCSV(this.results.products, `hidrospoint_prodotti_${timestamp}.csv`);
            }

            return this.results;
            
        } catch (error) {
            console.error('❌ Errore nello scraping:', error);
            throw error;
        }
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
            console.log('👋 Browser chiuso');
        }
    }
}

// ============ MAIN ============

async function main() {
    const scraper = new HidrosPointScraper();
    
    try {
        await scraper.init();
        
        // Prova a caricare cookies esistenti
        const cookiesLoaded = await scraper.loadCookies();
        
        // Se non ci sono cookies, fai login
        if (!cookiesLoaded) {
            if (CONFIG.credentials.username === 'TUO_USERNAME') {
                console.error('❌ ERRORE: Devi inserire le credenziali nel file CONFIG');
                console.log('💡 Opzioni:');
                console.log('   1. Modifica CONFIG.credentials nel file');
                console.log('   2. Usa variabili d\'ambiente: HIDROS_USERNAME e HIDROS_PASSWORD');
                console.log('   3. Fai login manualmente e salva i cookies');
                await scraper.close();
                return;
            }
            
            await scraper.login();
        } else {
            console.log('✅ Sessione ripristinata da cookies');
        }

        // Esegui lo scraping completo
        await scraper.scrapeAll();
        
    } catch (error) {
        console.error('❌ Errore fatale:', error);
    } finally {
        await scraper.close();
    }
}

// Esegui se chiamato direttamente
if (require.main === module) {
    main().catch(console.error);
}

module.exports = { HidrosPointScraper, CONFIG };
