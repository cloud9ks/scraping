/**
 * HIDROSPOINT B2B SCRAPER - Console Browser Version
 * 
 * ISTRUZIONI:
 * 1. Fai login manualmente su https://b2b.hidros.com
 * 2. Vai nella sezione "VALVOLAME E RACCORDERIA" o altra categoria
 * 3. Apri la console del browser (F12)
 * 4. Copia e incolla questo script
 * 5. Esegui: await scrapeHidrosPoint()
 */

async function scrapeHidrosPoint() {
    const results = {
        categories: [],
        products: [],
        brands: [],
        timestamp: new Date().toISOString()
    };

    console.log('🚀 Inizio scraping HidrosPoint B2B...');

    // Funzione per aspettare
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // 1. SCRAPING MARCHI dalla sidebar
    console.log('📊 Scraping marchi...');
    const brandsElements = document.querySelectorAll('.sidebar [class*="marchi"] a, .sidebar-left a');
    results.brands = Array.from(brandsElements).map(el => ({
        name: el.textContent.trim(),
        count: el.querySelector('[class*="count"]')?.textContent.trim() || null
    })).filter(b => b.name);

    console.log(`✅ Trovati ${results.brands.length} marchi`);

    // 2. SCRAPING CATEGORIE dal menu principale
    console.log('📂 Scraping categorie dal menu...');
    const categoryLinks = document.querySelectorAll('.mega-menu a, [class*="category"] a, [class*="menu"] a');
    
    const categories = new Set();
    categoryLinks.forEach(link => {
        const href = link.getAttribute('href');
        const text = link.textContent.trim();
        if (href && text && href.includes('category')) {
            categories.add(JSON.stringify({
                name: text,
                url: href.startsWith('http') ? href : 'https://b2b.hidros.com' + href
            }));
        }
    });

    results.categories = Array.from(categories).map(c => JSON.parse(c));
    console.log(`✅ Trovate ${results.categories.length} categorie`);

    // 3. SCRAPING PRODOTTI dalla pagina corrente
    console.log('🛍️ Scraping prodotti dalla pagina corrente...');
    
    // Trova tutti i blocchi prodotto
    const productBlocks = document.querySelectorAll('[class*="product"], .item-product, [class*="catalogo"] > div');
    
    console.log(`Trovati ${productBlocks.length} blocchi prodotto potenziali`);

    // Cerca pattern più specifici
    const productRows = document.querySelectorAll('table tbody tr, [class*="product-row"], [class*="item-row"]');
    
    if (productRows.length > 0) {
        console.log(`📋 Usando struttura tabella: ${productRows.length} righe`);
        
        productRows.forEach((row, index) => {
            try {
                const cells = row.querySelectorAll('td, [class*="cell"]');
                if (cells.length === 0) return;

                // Estrai informazioni
                const productCode = row.querySelector('[class*="model"], .modello, [class*="codice"]')?.textContent.trim();
                const productName = row.querySelector('[class*="name"], [class*="title"], h3, h4')?.textContent.trim();
                const price = row.querySelector('[class*="price"], [class*="prezzo"]')?.textContent.trim();
                const availability = row.querySelector('[class*="disponi"], [class*="stock"]')?.textContent.trim();
                const image = row.querySelector('img')?.src;

                // Estrai specifiche tecniche
                const specs = {};
                const specCells = row.querySelectorAll('td');
                specCells.forEach(cell => {
                    const text = cell.textContent.trim();
                    if (text && text.length < 50) {
                        const label = cell.getAttribute('data-label') || '';
                        if (label) specs[label] = text;
                    }
                });

                if (productCode || productName) {
                    results.products.push({
                        code: productCode || `PRODUCT_${index}`,
                        name: productName || 'N/A',
                        price: price || null,
                        availability: availability || null,
                        image: image || null,
                        specs: specs,
                        url: window.location.href
                    });
                }
            } catch (error) {
                console.warn(`⚠️ Errore nel processare riga ${index}:`, error);
            }
        });
    } else {
        console.log('🔍 Usando ricerca alternativa per prodotti...');
        
        // Strategia alternativa: cerca per struttura visibile negli screenshot
        const productContainers = document.querySelectorAll('[class*="catalog"] > div, .product-item, [class*="item"]');
        
        productContainers.forEach((container, index) => {
            try {
                const productCode = container.querySelector('[class*="B3003"], [class*="B8101"], [class*="model"]')?.textContent.trim();
                const productName = container.querySelector('h3, h4, [class*="title"], [class*="name"]')?.textContent.trim();
                const price = container.querySelector('[class*="price"], [class*="€"]')?.textContent.trim();
                const availability = container.querySelector('[class*="DISPONIBILE"], [class*="stock"]')?.textContent.trim();
                const image = container.querySelector('img')?.src;
                const brand = container.querySelector('[class*="brand"], [class*="marca"]')?.textContent.trim();

                if (productCode || productName || price) {
                    results.products.push({
                        code: productCode || `PRODUCT_${index}`,
                        name: productName || 'N/A',
                        price: price || null,
                        availability: availability || null,
                        brand: brand || null,
                        image: image || null,
                        url: window.location.href
                    });
                }
            } catch (error) {
                console.warn(`⚠️ Errore nel processare prodotto ${index}:`, error);
            }
        });
    }

    console.log(`✅ Trovati ${results.products.length} prodotti`);

    // 4. INFORMAZIONI PAGINA
    results.pageInfo = {
        title: document.title,
        url: window.location.href,
        category: document.querySelector('[class*="breadcrumb"], .category-name, h1')?.textContent.trim()
    };

    // 5. SALVA RISULTATI
    console.log('💾 Scraping completato!');
    console.log('📊 Riepilogo:', {
        brands: results.brands.length,
        categories: results.categories.length,
        products: results.products.length
    });

    // Scarica automaticamente il JSON
    const dataStr = JSON.stringify(results, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hidrospoint_scraping_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);

    console.log('✅ File JSON scaricato!');
    return results;
}

// Funzione per scraping completo di tutte le categorie
async function scrapeAllCategories() {
    console.log('🚀 Inizio scraping completo di tutte le categorie...');
    
    const allResults = {
        scrapingDate: new Date().toISOString(),
        categories: [],
        totalProducts: 0
    };

    // Primo scraping per ottenere lista categorie
    const initialData = await scrapeHidrosPoint();
    const categories = initialData.categories;

    console.log(`📂 Trovate ${categories.length} categorie da processare`);

    // Visita ogni categoria
    for (let i = 0; i < categories.length; i++) {
        const category = categories[i];
        console.log(`\n[${i + 1}/${categories.length}] Processando: ${category.name}`);
        
        try {
            // Naviga alla categoria
            window.location.href = category.url;
            
            // Aspetta caricamento (3 secondi)
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            // Scraping della categoria
            const categoryData = await scrapeHidrosPoint();
            
            allResults.categories.push({
                ...category,
                products: categoryData.products,
                productsCount: categoryData.products.length
            });
            
            allResults.totalProducts += categoryData.products.length;
            
            console.log(`✅ Categoria completata: ${categoryData.products.length} prodotti`);
            
            // Pausa tra le richieste
            await new Promise(resolve => setTimeout(resolve, 2000));
            
        } catch (error) {
            console.error(`❌ Errore nella categoria ${category.name}:`, error);
        }
    }

    // Scarica risultati completi
    const dataStr = JSON.stringify(allResults, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hidrospoint_completo_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);

    console.log('\n🎉 SCRAPING COMPLETO TERMINATO!');
    console.log(`📊 Totale prodotti: ${allResults.totalProducts}`);
    console.log(`📂 Totale categorie: ${allResults.categories.length}`);
    
    return allResults;
}

// Esporta anche in CSV
function exportToCSV(data) {
    const products = data.products || [];
    if (products.length === 0) {
        console.warn('⚠️ Nessun prodotto da esportare');
        return;
    }

    // Header CSV
    const headers = ['Codice', 'Nome', 'Prezzo', 'Disponibilità', 'Marca', 'URL', 'Immagine'];
    const rows = [headers.join(',')];

    // Dati
    products.forEach(product => {
        const row = [
            `"${product.code || ''}"`,
            `"${product.name || ''}"`,
            `"${product.price || ''}"`,
            `"${product.availability || ''}"`,
            `"${product.brand || ''}"`,
            `"${product.url || ''}"`,
            `"${product.image || ''}"`
        ];
        rows.push(row.join(','));
    });

    const csv = rows.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hidrospoint_products_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    console.log('✅ File CSV scaricato!');
}

console.log(`
╔═══════════════════════════════════════════════════════════╗
║      HIDROSPOINT B2B SCRAPER - Console Version          ║
╚═══════════════════════════════════════════════════════════╝

📋 COMANDI DISPONIBILI:

1. Scraping pagina corrente:
   await scrapeHidrosPoint()

2. Scraping completo tutte le categorie:
   await scrapeAllCategories()

3. Esporta ultimo scraping in CSV:
   const data = await scrapeHidrosPoint();
   exportToCSV(data);

Buon scraping! 🚀
`);
