/**
 * TEST RAPIDO HIDROSPOINT SCRAPER
 * 
 * Questo script fa un test veloce per verificare:
 * - Connessione al sito
 * - Login funzionante
 * - Selettori CSS corretti
 * - Estrazione di 1 prodotto di esempio
 * 
 * USO:
 * 1. Installa puppeteer: npm install puppeteer
 * 2. Modifica USERNAME e PASSWORD qui sotto
 * 3. Esegui: node test_hidrospoint.js
 */

const puppeteer = require('puppeteer');

// ⚙️ CONFIGURAZIONE
const USERNAME = 'TUO_USERNAME';
const PASSWORD = 'TUA_PASSWORD';
const TEST_URL = 'https://b2b.hidros.com/shop?category=10010001&category_detail=VALVOLE%20ARRESTO%20A%20SFERA&tab_name=VALVOLE%20ARRESTO%20A%20SFERA';

// Test dei selettori
const SELECTORS = {
    // Login
    loginUsername: 'input[name="username"], input[type="email"], #username',
    loginPassword: 'input[name="password"], input[type="password"], #password',
    loginButton: 'button[type="submit"], .btn-login, input[type="submit"]',
    
    // Prodotti (prova vari selettori)
    productRow: 'table tbody tr, .product-item, [class*="product-row"]',
    productCode: '[class*="model"], .modello, [class*="codice"]',
    productName: '[class*="name"], [class*="title"], h3, h4',
    productPrice: '[class*="price"], [class*="prezzo"]',
};

async function testScraper() {
    console.log('🧪 TEST HIDROSPOINT SCRAPER\n');
    
    const results = {
        connection: '❌',
        login: '❌',
        navigation: '❌',
        selectors: '❌',
        extraction: '❌'
    };

    let browser;
    
    try {
        // Test 1: Connessione
        console.log('1️⃣ Test connessione al sito...');
        browser = await puppeteer.launch({ 
            headless: false,
            slowMo: 50 
        });
        const page = await browser.newPage();
        await page.setViewport({ width: 1920, height: 1080 });
        results.connection = '✅';
        console.log('   ✅ Connessione OK\n');

        // Test 2: Login
        console.log('2️⃣ Test login...');
        if (USERNAME === 'TUO_USERNAME') {
            console.log('   ⚠️ ATTENZIONE: Devi inserire username e password nel file!');
            console.log('   ❌ Test login saltato\n');
        } else {
            try {
                await page.goto('https://b2b.hidros.com/login', { waitUntil: 'networkidle2' });
                
                // Trova e compila form
                await page.waitForSelector(SELECTORS.loginUsername, { timeout: 10000 });
                await page.type(SELECTORS.loginUsername, USERNAME);
                await page.type(SELECTORS.loginPassword, PASSWORD);
                
                // Click login e aspetta navigazione
                await Promise.all([
                    page.click(SELECTORS.loginButton),
                    page.waitForNavigation({ waitUntil: 'networkidle2' })
                ]);
                
                // Verifica successo
                const currentUrl = page.url();
                if (!currentUrl.includes('login')) {
                    results.login = '✅';
                    console.log('   ✅ Login effettuato con successo\n');
                } else {
                    console.log('   ❌ Login fallito - verifica credenziali\n');
                    throw new Error('Login failed');
                }
            } catch (error) {
                console.log('   ❌ Errore nel login:', error.message, '\n');
                throw error;
            }
        }

        // Test 3: Navigazione
        console.log('3️⃣ Test navigazione alla pagina prodotti...');
        try {
            await page.goto(TEST_URL, { waitUntil: 'networkidle2', timeout: 30000 });
            results.navigation = '✅';
            console.log('   ✅ Navigazione OK\n');
        } catch (error) {
            console.log('   ❌ Errore navigazione:', error.message, '\n');
            throw error;
        }

        // Test 4: Selettori
        console.log('4️⃣ Test selettori CSS...');
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const selectorTests = await page.evaluate((selectors) => {
            const tests = {};
            
            tests.productRows = document.querySelectorAll(selectors.productRow).length;
            tests.productCode = document.querySelectorAll(selectors.productCode).length;
            tests.productName = document.querySelectorAll(selectors.productName).length;
            tests.productPrice = document.querySelectorAll(selectors.productPrice).length;
            
            return tests;
        }, SELECTORS);
        
        console.log('   Risultati selettori:');
        console.log(`   - Righe prodotto: ${selectorTests.productRows}`);
        console.log(`   - Codici prodotto: ${selectorTests.productCode}`);
        console.log(`   - Nomi prodotto: ${selectorTests.productName}`);
        console.log(`   - Prezzi: ${selectorTests.productPrice}`);
        
        if (selectorTests.productRows > 0) {
            results.selectors = '✅';
            console.log('   ✅ Selettori OK\n');
        } else {
            console.log('   ⚠️ Nessun prodotto trovato - verifica selettori\n');
        }

        // Test 5: Estrazione dati
        console.log('5️⃣ Test estrazione primo prodotto...');
        const firstProduct = await page.evaluate((selectors) => {
            const row = document.querySelector(selectors.productRow);
            if (!row) return null;
            
            return {
                code: row.querySelector(selectors.productCode)?.textContent.trim() || 'N/A',
                name: row.querySelector(selectors.productName)?.textContent.trim() || 'N/A',
                price: row.querySelector(selectors.productPrice)?.textContent.trim() || 'N/A',
                html: row.innerHTML.substring(0, 200) + '...'
            };
        }, SELECTORS);

        if (firstProduct) {
            results.extraction = '✅';
            console.log('   ✅ Estrazione OK');
            console.log('   Esempio prodotto estratto:');
            console.log(`   - Codice: ${firstProduct.code}`);
            console.log(`   - Nome: ${firstProduct.name.substring(0, 50)}...`);
            console.log(`   - Prezzo: ${firstProduct.price}\n`);
        } else {
            console.log('   ❌ Nessun prodotto estratto\n');
        }

        // Screenshot per debug
        await page.screenshot({ path: './test_screenshot.png', fullPage: false });
        console.log('📸 Screenshot salvato in: test_screenshot.png\n');

    } catch (error) {
        console.error('\n❌ ERRORE DURANTE IL TEST:', error.message);
        console.error('\n🔍 Stack trace:', error.stack);
    } finally {
        if (browser) {
            await browser.close();
        }
    }

    // Riepilogo finale
    console.log('\n' + '='.repeat(50));
    console.log('📊 RIEPILOGO TEST:');
    console.log('='.repeat(50));
    console.log(`Connessione:       ${results.connection}`);
    console.log(`Login:             ${results.login}`);
    console.log(`Navigazione:       ${results.navigation}`);
    console.log(`Selettori CSS:     ${results.selectors}`);
    console.log(`Estrazione dati:   ${results.extraction}`);
    console.log('='.repeat(50));

    // Verdetto finale
    const allPassed = Object.values(results).every(r => r === '✅');
    
    if (allPassed) {
        console.log('\n🎉 TUTTI I TEST PASSATI!');
        console.log('✅ Puoi procedere con lo scraping completo\n');
    } else {
        console.log('\n⚠️ ALCUNI TEST FALLITI');
        console.log('🔧 Controlla i messaggi di errore sopra');
        console.log('💡 Suggerimenti:');
        if (results.login === '❌') {
            console.log('   - Verifica username e password');
        }
        if (results.selectors === '❌' || results.extraction === '❌') {
            console.log('   - I selettori CSS potrebbero essere cambiati');
            console.log('   - Controlla il file test_screenshot.png');
            console.log('   - Apri DevTools e verifica la struttura HTML');
        }
        console.log('');
    }
}

// Esegui test
if (require.main === module) {
    testScraper().catch(console.error);
}

module.exports = { testScraper };
