const puppeteer = require('puppeteer');
const fs = require('fs').promises;

const LOGIN_EMAIL = 'info@nextradeitalia.com';
const LOGIN_PASSWORD = '05391463';
const BASE_URL = 'https://b2b.hidros.com';

class AdvancedHidrosScraper {
    constructor() {
        this.browser = null;
        this.page = null;
        this.allProducts = [];
    }

    async init() {
        console.log('🚀 Avvio browser con stealth mode...');
        this.browser = await puppeteer.launch({
            headless: false,
            slowMo: 30,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-blink-features=AutomationControlled'
            ]
        });
        
        this.page = await this.browser.newPage();
        
        // Maschera Puppeteer
        await this.page.evaluateOnNewDocument(() => {
            Object.defineProperty(navigator, 'webdriver', {
                get: () => false,
            });
        });
        
        await this.page.setViewport({ width: 1920, height: 1080 });
        await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        this.page.setDefaultTimeout(60000);
    }

    async login() {
        console.log('🔐 Eseguo login...');
        await this.page.goto(BASE_URL, { waitUntil: 'networkidle0' });
        await this.page.waitForTimeout(2000);
        
        // Screenshot per debug
        await this.page.screenshot({ path: 'screenshots/01-before-login.png' });
        
        // Cerca il campo email con vari selettori
        const emailSelectors = [
            'input[type="email"]',
            'input[name="email"]',
            'input[name="username"]',
            'input[id*="email"]',
            'input[placeholder*="mail"]'
        ];
        
        let emailInput = null;
        for (const selector of emailSelectors) {
            try {
                await this.page.waitForSelector(selector, { timeout: 3000 });
                emailInput = selector;
                break;
            } catch (e) {
                continue;
            }
        }
        
        if (!emailInput) {
            throw new Error('Campo email non trovato');
        }
        
        // Compila il form come un utente reale
        await this.page.click(emailInput);
        await this.page.waitForTimeout(300);
        await this.page.type(emailInput, LOGIN_EMAIL, { delay: 100 });
        await this.page.waitForTimeout(500);
        
        // Password
        const passwordInput = 'input[type="password"]';
        await this.page.click(passwordInput);
        await this.page.waitForTimeout(300);
        await this.page.type(passwordInput, LOGIN_PASSWORD, { delay: 100 });
        await this.page.waitForTimeout(500);
        
        await this.page.screenshot({ path: 'screenshots/02-filled-form.png' });
        
        // Cerca e clicca il pulsante di submit
        const submitSelectors = [
            'button[type="submit"]',
            'input[type="submit"]',
            'button:has-text("Login")',
            'button:has-text("Accedi")',
            'button:has-text("Entra")'
        ];
        
        for (const selector of submitSelectors) {
            try {
                await this.page.waitForSelector(selector, { timeout: 2000 });
                await Promise.all([
                    this.page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 30000 }),
                    this.page.click(selector)
                ]);
                break;
            } catch (e) {
                continue;
            }
        }
        
        await this.page.waitForTimeout(3000);
        await this.page.screenshot({ path: 'screenshots/03-after-login.png' });
        console.log('✅ Login completato!');
    }

    async handleDropdownMenu(mainMenuText) {
        console.log(`\n🎯 Gestisco menu a tendina: ${mainMenuText}`);
        
        // Strategia 1: Hover sul menu principale
        try {
            const menuItem = await this.page.evaluateHandle((text) => {
                const elements = Array.from(document.querySelectorAll('a, button, li, div[class*="menu"]'));
                return elements.find(el => el.textContent.trim().includes(text));
            }, mainMenuText);
            
            if (menuItem) {
                const box = await menuItem.asElement().boundingBox();
                if (box) {
                    // Muovi il mouse sul menu
                    await this.page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
                    await this.page.waitForTimeout(1500);
                    
                    await this.page.screenshot({ path: `screenshots/menu-${mainMenuText.replace(/\s+/g, '-')}.png` });
                }
            }
        } catch (e) {
            console.log('⚠️ Hover fallito, provo con click...');
        }
        
        // Strategia 2: Click diretto se hover non funziona
        try {
            await this.page.evaluate((text) => {
                const elements = Array.from(document.querySelectorAll('a, button, li'));
                const element = elements.find(el => el.textContent.trim().includes(text));
                if (element) {
                    element.click();
                }
            }, mainMenuText);
            
            await this.page.waitForTimeout(2000);
        } catch (e) {
            console.log('⚠️ Click fallito');
        }
        
        // Estrai i link delle sottocategorie
        const subCategories = await this.page.evaluate(() => {
            const links = [];
            const visibleLinks = Array.from(document.querySelectorAll('a[href*="catalogo"], a[href*="categoria"]'));
            
            visibleLinks.forEach(link => {
                const rect = link.getBoundingClientRect();
                const isVisible = rect.width > 0 && rect.height > 0 && 
                                 rect.top >= 0 && rect.bottom <= window.innerHeight * 2;
                
                if (isVisible && link.href) {
                    links.push({
                        text: link.textContent.trim(),
                        url: link.href
                    });
                }
            });
            
            return links;
        });
        
        console.log(`   Trovate ${subCategories.length} sottocategorie`);
        return subCategories;
    }

    async extractProductsFromPage() {
        await this.page.waitForTimeout(2000);
        
        // Scroll per caricare tutti i prodotti
        await this.autoScroll();
        
        const products = await this.page.evaluate(() => {
            const items = [];
            
            // Cerca diverse strutture HTML possibili
            const selectors = [
                'tr[class*="product"]',
                'div[class*="product"]',
                '[data-product]',
                'article',
                'li[class*="item"]'
            ];
            
            let productElements = [];
            for (const selector of selectors) {
                productElements = document.querySelectorAll(selector);
                if (productElements.length > 0) break;
            }
            
            console.log(`Trovati ${productElements.length} elementi prodotto`);
            
            productElements.forEach((element, index) => {
                try {
                    const getAllText = (selectors) => {
                        for (const sel of selectors) {
                            const el = element.querySelector(sel);
                            if (el && el.textContent.trim()) {
                                return el.textContent.trim();
                            }
                        }
                        return '';
                    };
                    
                    // Estrazione dati con fallback multipli
                    const code = getAllText([
                        '[class*="code"]',
                        '[class*="model"]',
                        '[class*="MODELLO"]',
                        'td:nth-child(1)',
                        'span[class*="sku"]'
                    ]);
                    
                    const name = getAllText([
                        '[class*="name"]',
                        '[class*="title"]',
                        '[class*="description"]',
                        'h3', 'h4', 'h5',
                        'td:nth-child(2)',
                        'a[class*="product"]'
                    ]);
                    
                    const priceText = getAllText([
                        '[class*="price"]',
                        '[class*="PREZZO"]',
                        'td:nth-child(-2)',
                        'span[class*="amount"]'
                    ]);
                    
                    const price = priceText.replace(/[^\d,\.]/g, '').replace(',', '.');
                    
                    const availability = getAllText([
                        '[class*="stock"]',
                        '[class*="disponibil"]',
                        '[class*="DISPONIBILE"]',
                        'td:nth-child(3)',
                        'span[class*="availability"]'
                    ]);
                    
                    // Brand/Marca
                    let brand = '';
                    const brandImg = element.querySelector('img[alt]');
                    if (brandImg && brandImg.alt) {
                        brand = brandImg.alt;
                    } else {
                        brand = getAllText(['[class*="brand"]', '[class*="marca"]']);
                    }
                    
                    // Immagine
                    const img = element.querySelector('img');
                    const image = img ? img.src : '';
                    
                    // Link prodotto
                    const linkEl = element.querySelector('a[href]');
                    const productUrl = linkEl ? linkEl.href : '';
                    
                    // Raccogli tutto il testo per avere più contesto
                    const allText = element.textContent.trim();
                    
                    if (code || name || price) {
                        items.push({
                            code: code,
                            name: name,
                            price: price,
                            availability: availability,
                            brand: brand,
                            image: image,
                            productUrl: productUrl,
                            rawText: allText.substring(0, 200) // Primi 200 caratteri per debug
                        });
                    }
                } catch (error) {
                    console.error(`Errore prodotto ${index}:`, error.message);
                }
            });
            
            return items;
        });
        
        return products;
    }

    async scrapeCategoryUrl(url, categoryName) {
        console.log(`\n📦 Scraping: ${categoryName}`);
        console.log(`   URL: ${url}`);
        
        try {
            await this.page.goto(url, { waitUntil: 'networkidle2', timeout: 45000 });
            await this.page.waitForTimeout(3000);
            
            // Prova a cambiare la visualizzazione a lista se disponibile
            try {
                const listViewButton = await this.page.$('[class*="list-view"], [data-view="list"], button[title*="Lista"]');
                if (listViewButton) {
                    await listViewButton.click();
                    await this.page.waitForTimeout(1500);
                }
            } catch (e) {
                // Visualizzazione lista non disponibile
            }
            
            const products = await this.extractProductsFromPage();
            
            // Arricchisci con categoria
            products.forEach(p => {
                p.category = categoryName;
                p.categoryUrl = url;
                p.scrapedAt = new Date().toISOString();
            });
            
            console.log(`   ✅ Estratti ${products.length} prodotti`);
            this.allProducts.push(...products);
            
            // Salva screenshot
            await this.page.screenshot({ 
                path: `screenshots/category-${categoryName.replace(/[^a-zA-Z0-9]/g, '-')}.png`,
                fullPage: false
            });
            
            return products;
            
        } catch (error) {
            console.error(`   ❌ Errore: ${error.message}`);
            await this.page.screenshot({ 
                path: `screenshots/error-${categoryName.replace(/[^a-zA-Z0-9]/g, '-')}.png` 
            });
            return [];
        }
    }

    async autoScroll() {
        await this.page.evaluate(async () => {
            await new Promise((resolve) => {
                let totalHeight = 0;
                const distance = 200;
                const timer = setInterval(() => {
                    window.scrollBy(0, distance);
                    totalHeight += distance;
                    
                    if (totalHeight >= document.body.scrollHeight - window.innerHeight) {
                        clearInterval(timer);
                        window.scrollTo(0, 0); // Torna su
                        setTimeout(resolve, 500);
                    }
                }, 100);
            });
        });
    }

    async scrapeMainCategories() {
        console.log('\n🗂️  Analisi delle categorie principali...');
        
        // Naviga alla pagina principale
        await this.page.goto(`${BASE_URL}/valvolame-e-raccorderia`, { waitUntil: 'networkidle2' });
        await this.page.waitForTimeout(3000);
        await this.page.screenshot({ path: 'screenshots/04-main-categories.png' });
        
        // Lista delle categorie principali da esplorare
        const mainMenus = [
            'VALVOLAME E RACCORDERIA',
            'VALVOLE',
            'RUBINETTO',
            'COLLETTORI'
        ];
        
        let allSubCategories = [];
        
        for (const menuText of mainMenus) {
            const subCats = await this.handleDropdownMenu(menuText);
            allSubCategories.push(...subCats);
            await this.page.waitForTimeout(1000);
        }
        
        // Rimuovi duplicati
        const uniqueCategories = allSubCategories.filter((cat, index, self) =>
            index === self.findIndex((c) => c.url === cat.url)
        );
        
        console.log(`\n📋 Totale categorie uniche trovate: ${uniqueCategories.length}`);
        
        return uniqueCategories;
    }

    async scrapeAll() {
        try {
            // Crea cartella per screenshot
            await fs.mkdir('screenshots', { recursive: true });
            
            await this.init();
            await this.login();
            
            // Ottieni tutte le categorie
            const categories = await this.scrapeMainCategories();
            
            if (categories.length === 0) {
                console.log('⚠️  Nessuna categoria trovata, uso URL diretti...');
                
                // Fallback: URL diretti basati sulle immagini caricate
                const directCategories = [
                    { text: 'Valvole Arresto Sfera Ottone', url: `${BASE_URL}/riscaldamento/valvole-arresto-a-sfera` },
                    { text: 'Valvole di Zona', url: `${BASE_URL}/valvolame-e-raccorderia/valvole-elettrovalvole-e-valvole-di-zona-acqua` },
                    { text: 'Rubinetti Portagomma', url: `${BASE_URL}/valvolame-e-raccorderia/rubinetto-portagomma-ed-accessori` },
                ];
                
                for (const category of directCategories) {
                    await this.scrapeCategoryUrl(category.url, category.text);
                    await this.page.waitForTimeout(2000);
                }
            } else {
                // Scraping di tutte le categorie trovate
                console.log(`\n🚀 Inizio scraping di ${categories.length} categorie...\n`);
                
                for (let i = 0; i < categories.length; i++) {
                    const category = categories[i];
                    console.log(`\n[${i + 1}/${categories.length}] ${category.text}`);
                    
                    await this.scrapeCategoryUrl(category.url, category.text);
                    
                    // Pausa tra le categorie per non sovraccaricare il server
                    await this.page.waitForTimeout(2000 + Math.random() * 1000);
                }
            }
            
            await this.saveResults();
            
        } catch (error) {
            console.error('\n❌ ERRORE GENERALE:', error);
            await this.page.screenshot({ path: 'screenshots/fatal-error.png' });
        } finally {
            await this.close();
        }
    }

    async saveResults() {
        console.log(`\n\n💾 Salvataggio risultati...`);
        console.log(`   Totale prodotti: ${this.allProducts.length}`);
        
        if (this.allProducts.length === 0) {
            console.log('⚠️  Nessun prodotto da salvare!');
            return;
        }
        
        // JSON
        await fs.writeFile(
            'hidros-products-full.json',
            JSON.stringify(this.allProducts, null, 2),
            'utf8'
        );
        
        // CSV
        const headers = ['code', 'name', 'price', 'availability', 'brand', 'category', 'productUrl', 'image', 'scrapedAt'];
        const csvRows = [headers.join(',')];
        
        this.allProducts.forEach(product => {
            const row = headers.map(header => {
                const value = (product[header] || '').toString();
                return `"${value.replace(/"/g, '""')}"`;
            });
            csvRows.push(row.join(','));
        });
        
        await fs.writeFile('hidros-products-full.csv', csvRows.join('\n'), 'utf8');
        
        // Statistiche
        const stats = {
            totalProducts: this.allProducts.length,
            byCategory: {},
            byBrand: {},
            productsWithPrice: this.allProducts.filter(p => p.price).length,
            productsWithImage: this.allProducts.filter(p => p.image).length,
            scrapedAt: new Date().toISOString()
        };
        
        this.allProducts.forEach(p => {
            stats.byCategory[p.category] = (stats.byCategory[p.category] || 0) + 1;
            if (p.brand) {
                stats.byBrand[p.brand] = (stats.byBrand[p.brand] || 0) + 1;
            }
        });
        
        await fs.writeFile('hidros-stats.json', JSON.stringify(stats, null, 2), 'utf8');
        
        console.log('\n✅ File salvati:');
        console.log('   - hidros-products-full.json');
        console.log('   - hidros-products-full.csv');
        console.log('   - hidros-stats.json');
        
        console.log('\n📊 STATISTICHE FINALI:');
        console.log(`   Prodotti totali: ${stats.totalProducts}`);
        console.log(`   Prodotti con prezzo: ${stats.productsWithPrice}`);
        console.log(`   Prodotti con immagine: ${stats.productsWithImage}`);
        console.log('\n   Per categoria:');
        Object.entries(stats.byCategory).forEach(([cat, count]) => {
            console.log(`   - ${cat}: ${count}`);
        });
        console.log('\n   Per brand:');
        Object.entries(stats.byBrand).slice(0, 10).forEach(([brand, count]) => {
            console.log(`   - ${brand}: ${count}`);
        });
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
            console.log('\n👋 Scraping completato!');
        }
    }
}

// Esecuzione
(async () => {
    const scraper = new AdvancedHidrosScraper();
    await scraper.scrapeAll();
})();
