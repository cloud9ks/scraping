#!/usr/bin/env python3
"""
DEBUG VELOCE - Mostra i primi 50 link per capire la struttura
"""

import time
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

def debug_links():
    with open('config.json', 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    options = Options()
    driver = webdriver.Chrome(options=options)
    driver.maximize_window()
    
    try:
        # LOGIN
        print("LOGIN...")
        driver.get(config['site']['login_url'])
        time.sleep(3)
        
        email_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.login-container form input:nth-child(1)"))
        )
        email_field.send_keys(config['credentials']['email'])
        
        password_field = driver.find_element(By.CSS_SELECTOR, "div.login-container form input.form-wide.mt-3")
        password_field.send_keys(config['credentials']['password'])
        
        submit_button = driver.find_element(By.CSS_SELECTOR, "div.login-container form button")
        submit_button.click()
        time.sleep(5)
        
        # ESTRAI LINK
        print("\nESTRAZIONE LINK...")
        time.sleep(3)
        
        mobile_nav = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "nav.mobile-nav"))
        )
        
        all_links = driver.find_elements(By.CSS_SELECTOR, "nav.mobile-nav a")
        print(f"\nTOTALE: {len(all_links)} link")
        
        print("\n" + "="*80)
        print("PRIMI 50 LINK CON TESTO E URL:")
        print("="*80)
        
        for i, link in enumerate(all_links[:50], 1):
            try:
                href = link.get_attribute('href')
                text = link.text.strip()
                classes = link.get_attribute('class') or ''
                
                if text and len(text) > 2:
                    print(f"\n{i}. {text}")
                    print(f"   URL: {href}")
                    print(f"   Classi: {classes}")
                    
                    # Analisi URL
                    if '/collections/' in href:
                        print("   → COLLECTION")
                    elif '/products/' in href:
                        print("   → PRODUCT")
                    elif '/pages/' in href:
                        print("   → PAGE (da escludere)")
                    elif '/account' in href:
                        print("   → ACCOUNT (da escludere)")
                    else:
                        print("   → ALTRO")
            except:
                pass
        
        print("\n" + "="*80)
        input("\nPremi INVIO per chiudere...")
        
    finally:
        driver.quit()

if __name__ == "__main__":
    debug_links()
