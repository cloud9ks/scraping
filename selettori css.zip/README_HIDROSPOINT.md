# 🚀 HidrosPoint B2B Scraper - Guida Rapida

## 📦 File Disponibili

1. **hidrospoint_scraper_console.js** - Da eseguire nella console del browser
2. **hidrospoint_scraper_puppeteer.js** - Script Node.js con Puppeteer

---

## ⚡ METODO VELOCE: Console Browser

### Passi:
1. Apri https://b2b.hidros.com e **fai login**
2. Naviga alla sezione che vuoi scrapare
3. Premi **F12** per aprire DevTools
4. Vai sulla tab **Console**
5. Copia/incolla tutto il contenuto di `hidrospoint_scraper_console.js`
6. Esegui:
   ```javascript
   await scrapeHidrosPoint()
   ```
7. Il file JSON verrà scaricato automaticamente!

### Comandi disponibili:
```javascript
// Scraping pagina corrente
await scrapeHidrosPoint()

// Scraping TUTTE le categorie (automatico)
await scrapeAllCategories()

// Esporta in CSV
const data = await scrapeHidrosPoint();
exportToCSV(data);
```

---

## 🤖 METODO AUTOMATICO: Puppeteer

### Installazione:
```bash
npm install puppeteer
```

### Setup:
1. Apri `hidrospoint_scraper_puppeteer.js`
2. Modifica le credenziali:
   ```javascript
   credentials: {
       username: 'TUO_USERNAME',
       password: 'TUA_PASSWORD'
   }
   ```

### Esecuzione:
```bash
node hidrospoint_scraper_puppeteer.js
```

### Configurazione importante:
```javascript
const CONFIG = {
    waitTime: 2000,        // Pausa tra pagine (millisecondi)
    headless: false,       // true = nascosto, false = vedi browser
    outputFormat: 'both'   // 'json', 'csv', o 'both'
};
```

---

## 📊 Output

### JSON:
```json
{
  "products": [
    {
      "code": "B3003/8",
      "name": "VALVOLA ARRESTO A SFERA...",
      "price": "€3,0962",
      "availability": "DISPONIBILE",
      "brand": "BUGATTI",
      "category": "VALVOLE ARRESTO A SFERA"
    }
  ],
  "categories": [...],
  "brands": [...]
}
```

### CSV:
```
Codice,Nome,Prezzo,Disponibilità,Marca,Categoria
"B3003/8","VALVOLA...","€3,0962","DISPONIBILE","BUGATTI","VALVOLE..."
```

---

## 🔧 Troubleshooting

### ❌ Errore "Login fallito"
→ Verifica username/password nella sezione CONFIG

### ❌ Errore "Nessun prodotto trovato"  
→ I selettori CSS potrebbero essere cambiati, modificali nel file

### ❌ Timeout/errori di caricamento
→ Aumenta `waitTime` da 2000 a 3000 o più

### ❌ Script si blocca
→ Cancella cookies e riprova: 
```bash
rm hidros_scraping_output/cookies.json
```

---

## 💡 Tips

✅ **Consiglio #1**: Inizia con lo script Console - è più facile da debuggare

✅ **Consiglio #2**: Per scraping completo usa Puppeteer con `headless: false` la prima volta

✅ **Consiglio #3**: Non esagerare con la velocità - usa `waitTime: 2000` minimo

✅ **Consiglio #4**: I checkpoint vengono salvati ogni 5 categorie

---

## 🎯 Quale scegliere?

| Caratteristica | Console | Puppeteer |
|---------------|---------|-----------|
| Facile setup | ✅ | ⚠️ |
| Automatico | ⚠️ | ✅ |
| Debug | ✅ | ⚠️ |
| Headless | ❌ | ✅ |
| Checkpoint | ❌ | ✅ |

**Consiglio**: Inizia con Console, poi passa a Puppeteer per automazione completa

---

Buon scraping! 🚀
