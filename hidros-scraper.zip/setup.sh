#!/bin/bash

echo "🚀 HidrosPoint Scraper - Setup"
echo "================================"
echo ""

# Controlla Node.js
echo "📦 Verifico Node.js..."
if ! command -v node &> /dev/null; then
    echo "❌ Node.js non trovato!"
    echo "   Installa Node.js da: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v)
echo "✅ Node.js trovato: $NODE_VERSION"

# Controlla npm
echo ""
echo "📦 Verifico npm..."
if ! command -v npm &> /dev/null; then
    echo "❌ npm non trovato!"
    exit 1
fi

NPM_VERSION=$(npm -v)
echo "✅ npm trovato: $NPM_VERSION"

# Installa dipendenze
echo ""
echo "📥 Installazione dipendenze..."
npm install

if [ $? -eq 0 ]; then
    echo "✅ Dipendenze installate con successo!"
else
    echo "❌ Errore durante l'installazione delle dipendenze"
    exit 1
fi

# Crea cartelle necessarie
echo ""
echo "📁 Creazione cartelle..."
mkdir -p screenshots
echo "✅ Cartella screenshots/ creata"

# Test rapido
echo ""
echo "🧪 Eseguo test di verifica..."
echo "   (Questo aprirà un browser per 10 secondi)"
sleep 2

node hidros-test.js

echo ""
echo "================================"
echo "✅ Setup completato!"
echo ""
echo "🎯 Comandi disponibili:"
echo "   npm test         - Test di connessione"
echo "   npm start        - Scraper base"
echo "   npm run advanced - Scraper avanzato (consigliato)"
echo ""
echo "📚 Leggi README.md per maggiori info"
echo ""
