// config.example.js
// Copia questo file in config.js e modifica secondo le tue esigenze

module.exports = {
    // Credenziali di login
    credentials: {
        email: 'info@nextradeitalia.com',
        password: '05391463'
    },

    // URL del sito
    baseUrl: 'https://b2b.hidros.com',

    // Configurazione browser
    browser: {
        headless: false,        // true = invisibile, false = vedi il browser
        slowMo: 50,             // Velocità in ms (aumenta se hai problemi)
        timeout: 60000,         // Timeout generale in ms
        viewport: {
            width: 1920,
            height: 1080
        }
    },

    // Configurazione scraping
    scraping: {
        maxCategories: 50,      // Numero massimo di categorie da analizzare
        pauseBetweenPages: 2000, // Pausa tra le pagine in ms
        scrollDelay: 100,       // Velocità scroll in ms
        retryAttempts: 3,       // Tentativi in caso di errore
        screenshotsEnabled: true // Abilita/disabilita screenshot
    },

    // Selettori HTML (modifica se il sito cambia struttura)
    selectors: {
        login: {
            emailInput: 'input[type="email"], input[name="email"]',
            passwordInput: 'input[type="password"]',
            submitButton: 'button[type="submit"]'
        },
        products: {
            container: '[class*="product"], tr[class*="product"]',
            code: '[class*="code"], [class*="model"], [class*="MODELLO"]',
            name: '[class*="name"], [class*="title"], h3, h4',
            price: '[class*="price"], [class*="PREZZO"]',
            availability: '[class*="stock"], [class*="disponibil"], [class*="DISPONIBILE"]',
            brand: '[class*="brand"], .brand, img[alt]',
            image: 'img'
        },
        categories: {
            menu: 'a[href*="catalogo"], a[href*="categoria"]',
            dropdown: '[class*="menu"], li, a'
        }
    },

    // Categorie da scrapare (lascia vuoto per tutte)
    // Se specifichi categorie, verranno scrapate solo quelle
    targetCategories: [
        // Esempi:
        // 'Valvole Arresto Sfera',
        // 'Rubinetti',
        // 'Collettori'
    ],

    // Output
    output: {
        directory: './output',
        formats: ['json', 'csv'],  // Formati disponibili: json, csv, excel
        filenames: {
            json: 'hidros-products.json',
            csv: 'hidros-products.csv',
            stats: 'hidros-stats.json'
        },
        includeImages: true,    // Scarica anche le immagini
        includeRawData: false   // Includi dati raw per debug
    },

    // Filtri prodotti
    filters: {
        minPrice: 0,            // Prezzo minimo
        maxPrice: 999999,       // Prezzo massimo
        onlyAvailable: false,   // Solo prodotti disponibili
        brands: [],             // Lista brand (vuoto = tutti)
        excludeBrands: []       // Brand da escludere
    },

    // Logging
    logging: {
        level: 'info',          // debug, info, warn, error
        saveToFile: true,
        logFile: 'scraper.log'
    },

    // Rate limiting
    rateLimit: {
        enabled: true,
        requestsPerMinute: 30,  // Max richieste al minuto
        pauseAfterError: 5000   // Pausa dopo un errore in ms
    }
};
