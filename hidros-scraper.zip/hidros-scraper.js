const puppeteer = require('puppeteer');
const fs = require('fs').promises;

// Credenziali di login
const LOGIN_EMAIL = 'info@nextradeitalia.com';
const LOGIN_PASSWORD = '05391463';
const BASE_URL = 'https://b2b.hidros.com';

// Configurazione
const CONFIG = {
    headless: false, // Metti true per esecuzione invisibile
    slowMo: 50, // Rallenta le azioni per debug
    timeout: 60000
};

class HidrosScraper {
    constructor() {
        this.browser = null;
        this.page = null;
        this.allProducts = [];
    }

    async init() {
        console.log('🚀 Avvio browser...');
        this.browser = await puppeteer.launch({
            headless: CONFIG.headless,
            slowMo: CONFIG.slowMo,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        
        this.page = await this.browser.newPage();
        await this.page.setViewport({ width: 1920, height: 1080 });
        
        // Aumenta i timeout
        this.page.setDefaultTimeout(CONFIG.timeout);
        this.page.setDefaultNavigationTimeout(CONFIG.timeout);
    }

    async login() {
        console.log('🔐 Eseguo login...');
        await this.page.goto(BASE_URL, { waitUntil: 'networkidle2' });
        
        // Aspetta il form di login
        await this.page.waitForSelector('input[type="email"], input[name="email"]', { timeout: 10000 });
        
        // Compila il form
        const emailSelector = 'input[type="email"], input[name="email"]';
        const passwordSelector = 'input[type="password"], input[name="password"]';
        
        await this.page.type(emailSelector, LOGIN_EMAIL, { delay: 100 });
        await this.page.type(passwordSelector, LOGIN_PASSWORD, { delay: 100 });
        
        // Clicca sul pulsante di login
        await Promise.all([
            this.page.waitForNavigation({ waitUntil: 'networkidle2' }),
            this.page.click('button[type="submit"], input[type="submit"]')
        ]);
        
        console.log('✅ Login effettuato!');
        await this.page.screenshot({ path: 'login-success.png' });
    }

    async hoverAndWait(selector, waitTime = 1000) {
        await this.page.hover(selector);
        await this.page.waitForTimeout(waitTime);
    }

    async expandMenu(menuText) {
        console.log(`📂 Espando menu: ${menuText}`);
        
        // Trova e clicca sul menu principale
        const menuSelectors = [
            `a:has-text("${menuText}")`,
            `button:has-text("${menuText}")`,
            `[class*="menu"]:has-text("${menuText}")`,
            `li:has-text("${menuText}")`
        ];
        
        for (const selector of menuSelectors) {
            try {
                await this.page.waitForSelector(selector, { timeout: 5000 });
                await this.hoverAndWait(selector, 1500);
                return true;
            } catch (e) {
                continue;
            }
        }
        
        return false;
    }

    async scrapeCategory(categoryUrl, categoryName) {
        console.log(`\n📦 Scraping categoria: ${categoryName}`);
        console.log(`🔗 URL: ${categoryUrl}`);
        
        try {
            await this.page.goto(categoryUrl, { waitUntil: 'networkidle2', timeout: 30000 });
            await this.page.waitForTimeout(2000);
            
            // Aspetta che i prodotti siano caricati
            await this.page.waitForSelector('[class*="product"], .product-item, [data-product]', { timeout: 10000 });
            
            // Scroll per caricare eventuali lazy-loaded items
            await this.autoScroll();
            
            // Estrai i prodotti
            const products = await this.page.evaluate((category) => {
                const items = [];
                
                // Cerca vari selettori possibili per i prodotti
                const productElements = document.querySelectorAll('[class*="product-"], .product, [data-product], tr[class*="product"]');
                
                productElements.forEach((element, index) => {
                    try {
                        // Estrai codice prodotto
                        const codeElement = element.querySelector('[class*="code"], [class*="model"], .model, .code, [class*="MODELLO"]');
                        const code = codeElement ? codeElement.textContent.trim() : '';
                        
                        // Estrai nome/descrizione
                        const nameElement = element.querySelector('[class*="name"], [class*="title"], .title, h3, h4, [class*="description"]');
                        const name = nameElement ? nameElement.textContent.trim() : '';
                        
                        // Estrai prezzo
                        const priceElement = element.querySelector('[class*="price"], .price, [class*="PREZZO"]');
                        const priceText = priceElement ? priceElement.textContent.trim() : '';
                        const price = priceText.replace(/[^\d,\.]/g, '').replace(',', '.');
                        
                        // Estrai disponibilità
                        const availabilityElement = element.querySelector('[class*="stock"], [class*="disponibil"], .availability, [class*="DISPONIBILE"]');
                        const availability = availabilityElement ? availabilityElement.textContent.trim() : '';
                        
                        // Estrai brand
                        const brandElement = element.querySelector('[class*="brand"], .brand, img[alt]');
                        const brand = brandElement ? (brandElement.alt || brandElement.textContent.trim()) : '';
                        
                        // Estrai immagine
                        const imageElement = element.querySelector('img');
                        const image = imageElement ? imageElement.src : '';
                        
                        if (code || name) {
                            items.push({
                                category: category,
                                code: code,
                                name: name,
                                price: price,
                                availability: availability,
                                brand: brand,
                                image: image,
                                scrapedAt: new Date().toISOString()
                            });
                        }
                    } catch (error) {
                        console.error(`Errore nell'estrazione del prodotto ${index}:`, error.message);
                    }
                });
                
                return items;
            }, categoryName);
            
            console.log(`✅ Trovati ${products.length} prodotti in ${categoryName}`);
            this.allProducts.push(...products);
            
            return products;
            
        } catch (error) {
            console.error(`❌ Errore nello scraping di ${categoryName}:`, error.message);
            return [];
        }
    }

    async autoScroll() {
        await this.page.evaluate(async () => {
            await new Promise((resolve) => {
                let totalHeight = 0;
                const distance = 100;
                const timer = setInterval(() => {
                    const scrollHeight = document.body.scrollHeight;
                    window.scrollBy(0, distance);
                    totalHeight += distance;

                    if (totalHeight >= scrollHeight) {
                        clearInterval(timer);
                        resolve();
                    }
                }, 100);
            });
        });
    }

    async getAllCategories() {
        console.log('🔍 Ricerca di tutte le categorie...');
        
        // Naviga alla pagina principale delle categorie
        await this.page.goto(`${BASE_URL}/valvolame-e-raccorderia`, { waitUntil: 'networkidle2' });
        await this.page.waitForTimeout(2000);
        
        // Estrai tutti i link delle categorie
        const categories = await this.page.evaluate(() => {
            const links = [];
            const categoryLinks = document.querySelectorAll('a[href*="/catalogo"], a[href*="/categoria"], a[href*="valvol"], a[href*="rubinetto"]');
            
            categoryLinks.forEach(link => {
                const href = link.href;
                const text = link.textContent.trim();
                
                if (href && text && !links.find(l => l.url === href)) {
                    links.push({
                        name: text,
                        url: href
                    });
                }
            });
            
            return links;
        });
        
        console.log(`📋 Trovate ${categories.length} categorie`);
        return categories;
    }

    async scrapeAll() {
        try {
            await this.init();
            await this.login();
            
            // Strategia 1: Prova a ottenere tutte le categorie automaticamente
            const categories = await this.getAllCategories();
            
            if (categories.length > 0) {
                for (const category of categories.slice(0, 5)) { // Prime 5 categorie per test
                    await this.scrapeCategory(category.url, category.name);
                    await this.page.waitForTimeout(2000); // Pausa tra le categorie
                }
            } else {
                // Strategia 2: URL manuali dalle immagini
                console.log('⚠️ Uso URL manuali...');
                const manualCategories = [
                    { name: 'Valvole Arresto Sfera Ottone', url: `${BASE_URL}/catalogo?search=valvola+arresto+sfera` },
                    { name: 'Valvole di Zona', url: `${BASE_URL}/catalogo?search=valvola+zona` },
                    { name: 'Rubinetti', url: `${BASE_URL}/catalogo?search=rubinetto` },
                ];
                
                for (const category of manualCategories) {
                    await this.scrapeCategory(category.url, category.name);
                    await this.page.waitForTimeout(2000);
                }
            }
            
            // Salva i risultati
            await this.saveResults();
            
        } catch (error) {
            console.error('❌ Errore generale:', error);
            await this.page.screenshot({ path: 'error-screenshot.png' });
        } finally {
            await this.close();
        }
    }

    async saveResults() {
        console.log(`\n💾 Salvataggio di ${this.allProducts.length} prodotti...`);
        
        // Salva in JSON
        await fs.writeFile(
            'hidros-products.json',
            JSON.stringify(this.allProducts, null, 2),
            'utf8'
        );
        
        // Salva in CSV
        if (this.allProducts.length > 0) {
            const headers = Object.keys(this.allProducts[0]);
            const csvContent = [
                headers.join(','),
                ...this.allProducts.map(product => 
                    headers.map(header => {
                        const value = product[header] || '';
                        return `"${value.toString().replace(/"/g, '""')}"`;
                    }).join(',')
                )
            ].join('\n');
            
            await fs.writeFile('hidros-products.csv', csvContent, 'utf8');
        }
        
        console.log('✅ File salvati: hidros-products.json e hidros-products.csv');
        
        // Stampa statistiche
        console.log('\n📊 STATISTICHE:');
        console.log(`   Totale prodotti: ${this.allProducts.length}`);
        
        const categoryCounts = this.allProducts.reduce((acc, product) => {
            acc[product.category] = (acc[product.category] || 0) + 1;
            return acc;
        }, {});
        
        console.log('   Per categoria:');
        Object.entries(categoryCounts).forEach(([cat, count]) => {
            console.log(`   - ${cat}: ${count} prodotti`);
        });
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
            console.log('👋 Browser chiuso');
        }
    }
}

// Esegui lo scraper
(async () => {
    const scraper = new HidrosScraper();
    await scraper.scrapeAll();
})();
