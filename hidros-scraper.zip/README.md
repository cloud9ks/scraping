# HidrosPoint B2B Scraper

Scraper JavaScript per estrarre prodotti dal sito B2B di HidrosPoint usando Puppeteer.

## 🎯 Caratteristiche

- ✅ Login automatico
- ✅ Gestione menu a tendina dinamici
- ✅ Estrazione completa dei prodotti
- ✅ Export in JSON e CSV
- ✅ Screenshot per debug
- ✅ Statistiche dettagliate
- ✅ Gestione errori robusta

## 📋 Prerequisiti

- Node.js (versione 16 o superiore)
- npm o yarn

## 🚀 Installazione

1. **Installa le dipendenze:**

```bash
npm install
```

Questo installerà:
- `puppeteer` - Browser automation
- Chromium (scaricato automaticamente da Puppeteer)

## 💻 Utilizzo

### Test di Connessione

Prima di tutto, verifica che il login funzioni:

```bash
npm test
```

Questo script:
- Prova a fare il login
- Naviga al catalogo
- Fa alcuni screenshot
- Mostra se tutto funziona correttamente

### Scraper Base

Per una versione semplice e veloce:

```bash
npm start
```

Estrae prodotti dalle categorie principali e salva:
- `hidros-products.json` - Tutti i prodotti in formato JSON
- `hidros-products.csv` - Tutti i prodotti in formato CSV

### Scraper Avanzato (CONSIGLIATO)

Per una versione completa con gestione avanzata dei menu:

```bash
npm run advanced
```

Questo script:
- Esplora automaticamente tutti i menu a tendina
- Estrae TUTTE le categorie disponibili
- Gestisce meglio i menu dinamici
- Crea screenshot di debug nella cartella `screenshots/`
- Salva file più dettagliati:
  - `hidros-products-full.json`
  - `hidros-products-full.csv`
  - `hidros-stats.json` (statistiche)

## 📊 Output

### Formato JSON

```json
[
  {
    "code": "B8101",
    "name": "VALVOLA ARRESTO A SFERA IN OTTONE CON LEVA FEMMINA FEMMINA",
    "price": "6.5377",
    "availability": "DISPONIBILE",
    "brand": "BUGATTI",
    "category": "Valvole Arresto Sfera",
    "productUrl": "https://b2b.hidros.com/...",
    "image": "https://...",
    "scrapedAt": "2025-11-04T..."
  }
]
```

### Formato CSV

```csv
code,name,price,availability,brand,category,productUrl,image,scrapedAt
"B8101","VALVOLA ARRESTO...","6.5377","DISPONIBILE","BUGATTI",...
```

## ⚙️ Configurazione

Puoi modificare le impostazioni negli script:

```javascript
const CONFIG = {
    headless: false,  // true = invisibile, false = vedi il browser
    slowMo: 50,       // Velocità (ms) - aumenta se hai problemi
    timeout: 60000    // Timeout in ms
};
```

## 🔍 Debug

### Screenshot automatici

Lo scraper avanzato crea screenshot in `screenshots/`:
- `01-before-login.png` - Prima del login
- `02-filled-form.png` - Form compilato
- `03-after-login.png` - Dopo il login
- `04-main-categories.png` - Pagina categorie
- `menu-*.png` - Screenshot dei menu
- `category-*.png` - Screenshot di ogni categoria
- `error-*.png` - Screenshot in caso di errori

### Modalità Debug

Per vedere cosa sta facendo lo scraper:

1. Imposta `headless: false` (già default)
2. Aumenta `slowMo` a 100-200ms
3. Guarda il browser mentre lavora

### Log Dettagliati

Gli script mostrano log colorati nel terminale:
- 🚀 Avvio
- 🔐 Login
- 📂 Menu
- 📦 Categorie
- ✅ Successi
- ⚠️ Warning
- ❌ Errori

## 🛠️ Troubleshooting

### Problema: Login fallisce

**Soluzione:**
1. Verifica le credenziali in `hidros-scraper.js`:
   ```javascript
   const LOGIN_EMAIL = 'info@nextradeitalia.com';
   const LOGIN_PASSWORD = '05391463';
   ```
2. Controlla gli screenshot in `screenshots/`
3. Prova a rallentare: imposta `slowMo: 200`

### Problema: Nessun prodotto estratto

**Soluzione:**
1. Esegui prima `npm test` per verificare la connessione
2. Usa lo scraper avanzato: `npm run advanced`
3. Controlla gli screenshot delle categorie
4. Il sito potrebbe aver cambiato struttura HTML - contattami per aggiornare i selettori

### Problema: Menu a tendina non si aprono

**Soluzione:**
1. Usa lo scraper avanzato che ha strategie multiple
2. Aumenta i tempi di attesa nel codice:
   ```javascript
   await this.page.waitForTimeout(2000); // Aumenta a 3000-4000
   ```
3. Verifica che JavaScript sia abilitato sul sito

### Problema: Timeout durante lo scraping

**Soluzione:**
1. Aumenta il timeout globale:
   ```javascript
   this.page.setDefaultTimeout(90000); // 90 secondi
   ```
2. Controlla la connessione internet
3. Il server potrebbe essere lento - aggiungi pause:
   ```javascript
   await this.page.waitForTimeout(3000);
   ```

## 📝 Struttura dei File

```
.
├── package.json                      # Dipendenze
├── hidros-scraper.js                 # Scraper base
├── hidros-scraper-advanced.js        # Scraper avanzato (consigliato)
├── hidros-test.js                    # Script di test
├── screenshots/                       # Screenshot di debug
├── hidros-products.json              # Output JSON (base)
├── hidros-products.csv               # Output CSV (base)
├── hidros-products-full.json         # Output JSON completo
├── hidros-products-full.csv          # Output CSV completo
└── hidros-stats.json                 # Statistiche
```

## 🔧 Personalizzazione

### Modificare le Categorie Target

Nello scraper base, modifica:

```javascript
const manualCategories = [
    { name: 'Nome Categoria', url: 'https://b2b.hidros.com/...' },
    // Aggiungi altre categorie
];
```

### Cambiare i Campi Estratti

Modifica la funzione `extractProductsFromPage()` per estrarre campi aggiuntivi:

```javascript
const newField = getAllText([
    '[class*="nuovo-campo"]',
    '.nuovo-campo'
]);
```

### Aggiungere Filtri

```javascript
// Filtra solo prodotti disponibili
const availableProducts = products.filter(p => 
    p.availability && p.availability.includes('DISPONIBILE')
);
```

## ⚡ Performance

### Velocizzare lo Scraping

1. **Modalità headless:**
   ```javascript
   headless: true  // Non mostra il browser
   ```

2. **Riduci slowMo:**
   ```javascript
   slowMo: 10  // Più veloce
   ```

3. **Limita le categorie:**
   ```javascript
   for (const category of categories.slice(0, 10)) {
       // Prendi solo le prime 10
   }
   ```

### Rispettare il Server

⚠️ **IMPORTANTE:** Non abusare dello scraper!

- Aggiungi pause tra le richieste
- Non eseguire troppo frequentemente
- Rispetta i Terms of Service del sito

## 📜 Note Legali

Questo scraper è fornito solo a scopo educativo. Assicurati di:
- Avere il permesso per fare scraping del sito
- Rispettare i Terms of Service
- Non sovraccaricare il server
- Usare i dati estratti in modo responsabile

## 🐛 Segnalazione Bug

Se trovi problemi:
1. Controlla gli screenshot nella cartella `screenshots/`
2. Verifica i log nel terminale
3. Prova prima lo script di test: `npm test`
4. Includi screenshot e log quando segnali il problema

## 📈 Prossimi Miglioramenti

- [ ] Proxy rotation
- [ ] Retry automatico su errori
- [ ] Export in Excel
- [ ] Database integration (MongoDB/PostgreSQL)
- [ ] Scheduling automatico (cron)
- [ ] API REST per accedere ai dati
- [ ] Dashboard web per visualizzare i prodotti

## 🤝 Contributi

Migliorie e fix sono benvenuti!

## 📄 Licenza

MIT License - Usa liberamente, a tuo rischio!

---

**Buon scraping! 🚀**
