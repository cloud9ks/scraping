#!/usr/bin/env python3
"""
SETUP RAPIDO - Hidros Scraper Corretto

Questo script ti guida nel test e nell'utilizzo dello scraper corretto.
"""

import os
import sys
import subprocess

def print_banner():
    print("\n" + "="*60)
    print(" 🔧 HIDROS SCRAPER - VERSIONE CORRETTA")
    print("="*60)
    print()
    print("✅ Problema identificato e risolto!")
    print("📦 File corretti pronti all'uso")
    print()

def check_dependencies():
    print("📋 Verifica dipendenze...")
    
    missing = []
    
    try:
        import selenium
        print("  ✓ selenium")
    except ImportError:
        missing.append("selenium")
        print("  ✗ selenium")
    
    try:
        import pandas
        print("  ✓ pandas")
    except ImportError:
        missing.append("pandas")
        print("  ✗ pandas")
    
    try:
        import requests
        print("  ✓ requests")
    except ImportError:
        missing.append("requests")
        print("  ✗ requests")
    
    if missing:
        print(f"\n⚠️  Dipendenze mancanti: {', '.join(missing)}")
        print(f"📥 Installa con: pip install {' '.join(missing)}")
        return False
    
    print("\n✅ Tutte le dipendenze installate!")
    return True

def show_menu():
    print("\n" + "="*60)
    print(" MENU PRINCIPALE")
    print("="*60)
    print()
    print("1. TEST RAPIDO - Verifica estrazione categorie (30 sec)")
    print("2. SCRAPING COMPLETO - Tutto il catalogo (30-60 min)")
    print("3. Leggi documentazione problema/soluzione")
    print("4. Verifica configurazione")
    print()
    print("0. Esci")
    print()

def run_quick_test():
    print("\n🚀 Avvio test rapido...")
    print("="*60)
    try:
        result = subprocess.run([sys.executable, "test_categories_quick.py"], 
                              capture_output=False)
        return result.returncode == 0
    except Exception as e:
        print(f"❌ Errore: {e}")
        return False

def run_full_scraping():
    print("\n🚀 Avvio scraping completo...")
    print("="*60)
    print("⚠️  Questo può richiedere 30-60 minuti!")
    confirm = input("\nSei sicuro? (digita 'SI'): ").strip()
    
    if confirm != "SI":
        print("Annullato.")
        return
    
    try:
        result = subprocess.run([sys.executable, "hidros_scraper_FIXED.py"], 
                              capture_output=False)
        return result.returncode == 0
    except Exception as e:
        print(f"❌ Errore: {e}")
        return False

def show_documentation():
    print("\n📖 DOCUMENTAZIONE PROBLEMA/SOLUZIONE")
    print("="*60)
    
    if os.path.exists("SOLUZIONE.md"):
        with open("SOLUZIONE.md", 'r', encoding='utf-8') as f:
            content = f.read()
        print(content)
    else:
        print("❌ File SOLUZIONE.md non trovato")
    
    input("\n\nPremi INVIO per continuare...")

def verify_config():
    print("\n⚙️  VERIFICA CONFIGURAZIONE")
    print("="*60)
    
    if not os.path.exists("config.json"):
        print("❌ File config.json non trovato!")
        return False
    
    try:
        import json
        with open("config.json", 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        print("✅ File config.json valido")
        print(f"\nCredenziali:")
        print(f"  Email: {config['credentials']['email']}")
        print(f"  Password: {'*' * len(config['credentials']['password'])}")
        print(f"\nURL:")
        print(f"  Login: {config['site']['login_url']}")
        print(f"  Base: {config['site']['base_url']}")
        print(f"\nOutput:")
        print(f"  Directory: {config['output']['directory']}")
        
        return True
    except Exception as e:
        print(f"❌ Errore nel config: {e}")
        return False

def main():
    print_banner()
    
    # Verifica dipendenze
    if not check_dependencies():
        print("\n❌ Installa le dipendenze prima di continuare.")
        sys.exit(1)
    
    # Menu principale
    while True:
        show_menu()
        choice = input("Scegli un'opzione: ").strip()
        
        if choice == "1":
            run_quick_test()
            input("\nPremi INVIO per continuare...")
        
        elif choice == "2":
            run_full_scraping()
            input("\nPremi INVIO per continuare...")
        
        elif choice == "3":
            show_documentation()
        
        elif choice == "4":
            verify_config()
            input("\nPremi INVIO per continuare...")
        
        elif choice == "0":
            print("\n👋 Arrivederci!")
            break
        
        else:
            print("\n❌ Opzione non valida")
            input("Premi INVIO...")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrotto dall'utente.")
        sys.exit(0)
